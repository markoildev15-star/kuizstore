#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
[[ $EUID -eq 0 ]] || { echo 'Запусти: sudo bash setup.sh'; exit 1; }
[[ -t 0 ]] || { echo 'Нужен интерактивный терминал'; exit 1; }
cd "$(dirname "$(readlink -f "$0")")"
[[ -f server/store.py && -f deploy/nginx.conf ]] || { echo 'Запускай из распакованного архива'; exit 1; }
[[ ! -e /etc/kuizstore/kuizstore.env && ! -e /etc/nginx/sites-available/kuizstore ]] || { echo 'Конфигурация KuizStore уже существует. Остановлено, чтобы не перезаписать её.'; exit 1; }
read -r -p 'Email для Certbot: ' email
client=c85e0078fbacc59521344b568a4929a3
read -r -s -p 'Markol Auth client secret: ' secret; echo
[[ -n $email && -n $client && -n $secret && $client != *[[:space:]\"\'\#\\]* && $secret != *[[:space:]\"\'\#\\]* ]] || { echo 'Пустые значения и пробелы/кавычки в credentials не поддерживаются.'; exit 1; }
echo 'Устанавливаю зависимости. Порт 80 должен быть доступен извне, DNS store.markol.fun должен указывать на этот сервер.'
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y nginx certbot python3-certbot-nginx python3-venv python3-pil acl rsync aapt apksigner
id kuizstore >/dev/null 2>&1 || useradd --system --home-dir /var/lib/kuizstore --shell /usr/sbin/nologin kuizstore
install -d -m 755 /opt/kuizstore /var/lib/kuizstore/files /etc/kuizstore
rsync -a --exclude .venv --exclude __pycache__ --exclude '*.db*' --exclude files server site deploy /opt/kuizstore/
python3 -m venv --system-site-packages /opt/kuizstore/.venv
chmod -R a+rX /opt/kuizstore/.venv
/opt/kuizstore/.venv/bin/python -c 'import PIL'
chown -R kuizstore:kuizstore /var/lib/kuizstore
setfacl -m u:www-data:--x /var/lib/kuizstore
setfacl -R -m u:www-data:rX /var/lib/kuizstore/files
find /var/lib/kuizstore/files -type d -exec setfacl -m d:u:www-data:rX {} +
key=$(/opt/kuizstore/.venv/bin/python -c 'import secrets; print(secrets.token_hex(32))')
cat > /etc/kuizstore/kuizstore.env <<ENV
MARKAUTH_BASE_URL=https://auth.markol.fun
MARKAUTH_CLIENT_ID=$client
MARKAUTH_CLIENT_SECRET=$secret
MARKAUTH_CALLBACK=https://store.markol.fun/auth/callback
APP_SESSION_KEY=$key
MARKAUTH_CONTRACT_FILE=/etc/kuizstore/auth-contract.json
ADMIN_ALLOWLIST_FILE=/etc/kuizstore/admin-allowlist.json
KUIZ_DB=/var/lib/kuizstore/store.db
KUIZ_FILES=/var/lib/kuizstore/files
PORT=8092
TRUST_LOCAL_PROXY=1
PATH=/usr/local/bin:/usr/bin:/bin
ENV
unset secret key
cp deploy/auth-contract.example.json /etc/kuizstore/auth-contract.json
cp deploy/admin-allowlist.example.json /etc/kuizstore/admin-allowlist.json
chown root:kuizstore /etc/kuizstore/*.json /etc/kuizstore/kuizstore.env
chmod 640 /etc/kuizstore/*.json /etc/kuizstore/kuizstore.env
chown root:kuizstore /etc/kuizstore
chmod 750 /etc/kuizstore
chmod -R a+rX /opt/kuizstore/site /opt/kuizstore/server
cp deploy/kuizstore.service /etc/systemd/system/kuizstore.service
systemctl daemon-reload
systemctl enable --now kuizstore
cat > /etc/nginx/sites-available/kuizstore <<'NGINX'
server {
    listen 80;
    server_name store.markol.fun;
    root /var/www/html;
    location ^~ /.well-known/acme-challenge/ { try_files $uri =404; }
    location / { return 404; }
}
NGINX
ln -s /etc/nginx/sites-available/kuizstore /etc/nginx/sites-enabled/kuizstore
nginx -t
systemctl reload nginx
certbot certonly --webroot -w /var/www/html -d store.markol.fun --email "$email" --agree-tos --no-eff-email --non-interactive || { echo 'Сертификат не получен. Проверь DNS, порт 80 и конфигурацию Nginx.'; exit 1; }
{
 echo 'server {'
 echo '    listen 80;'
 echo '    server_name store.markol.fun;'
 echo '    root /var/www/html;'
 echo '    location ^~ /.well-known/acme-challenge/ { try_files $uri =404; }'
 echo '    location / { return 301 https://$host$request_uri; }'
 echo '}'
 echo 'server {'
 echo '    listen 443 ssl;'
 echo '    server_name store.markol.fun;'
 echo '    ssl_certificate /etc/letsencrypt/live/store.markol.fun/fullchain.pem;'
 echo '    ssl_certificate_key /etc/letsencrypt/live/store.markol.fun/privkey.pem;'
 cat /opt/kuizstore/deploy/nginx.conf
 echo '}'
} > /etc/nginx/sites-available/kuizstore
nginx -t
systemctl reload nginx
systemctl enable --now certbot.timer
printf '\nГотово. Вход пока отключён: подтвердите контракт userinfo и настройте /etc/kuizstore/auth-contract.json и admin-allowlist.json.\n\n'
