package store.kuiz

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/** Pictures from the store's server: fetched once, kept in memory while the app runs. */
object Pictures {
    private val kept = object : LruCache<String, Bitmap>(24 shl 20) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    fun known(address: String): Bitmap? = kept.get(address)

    suspend fun fetch(address: String, most: Int): Bitmap? = withContext(Dispatchers.IO) {
        kept.get(address)?.let { return@withContext it }
        try {
            val link = URL(address).openConnection() as HttpURLConnection
            link.connectTimeout = 15_000
            link.readTimeout = 30_000
            val bytes = try { link.inputStream.use { it.readBytes() } } finally { link.disconnect() }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= most && bounds.outHeight / (sample * 2) >= most) sample *= 2
            val picture = BitmapFactory.decodeByteArray(bytes, 0, bytes.size,
                BitmapFactory.Options().apply { inSampleSize = sample }) ?: return@withContext null
            kept.put(address, picture)
            picture
        } catch (failed: Exception) {
            null
        }
    }

    fun forget(address: String) { kept.remove(address) }
}

/** A picture by its address, with [placeholder] until it is here (or when there is none). */
@Composable
fun Picture(address: String, modifier: Modifier, most: Int = 512, crop: Boolean = true, tint: Color? = null,
            placeholder: @Composable () -> Unit = { Box(modifier.background(Color.Gray.copy(alpha = 0.15f))) }) {
    var picture by remember(address) { mutableStateOf(if (address.isEmpty()) null else Pictures.known(address)) }
    LaunchedEffect(address) {
        if (address.isNotEmpty() && picture == null) picture = Pictures.fetch(address, most)
    }
    val shown = picture
    if (shown == null) placeholder()
    else Image(shown.asImageBitmap(), contentDescription = null, modifier = modifier,
        contentScale = if (crop) ContentScale.Crop else ContentScale.Fit,
        colorFilter = tint?.let { ColorFilter.tint(it, BlendMode.SrcIn) })
}
