package store.kuiz

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import org.json.JSONObject

private fun JSONObject.rows(name: String): List<JSONObject> {
    val array = optJSONArray(name) ?: return emptyList()
    return List(array.length()) { array.getJSONObject(it) }
}
class MainActivity: ComponentActivity() {
    private val client by lazy { Client(applicationContext) }
    private var installedRevision by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); installedRevision++ }
    private var callback by mutableStateOf<Uri?>(null)
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        callback=intent.data
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if(savedInstanceState==null) callback=intent.data
        enableEdgeToEdge()
        setContent { Store() }
    }
    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun Store() {
        val prefs = remember { getSharedPreferences("appearance",MODE_PRIVATE) }
        var theme by remember { mutableStateOf(prefs.getString("theme","system") ?: "system") }
        var dynamic by remember { mutableStateOf(prefs.getBoolean("dynamic",true)) }
        var stack by rememberSaveable { mutableStateOf(arrayListOf("catalog")) }
        val page=stack.last()
        var forward by remember { mutableStateOf(true) }
        fun go(next:String) { if(next!=page) { forward=true; stack=ArrayList(stack+next) } }
        fun back() { if(stack.size>1) { forward=false; stack=ArrayList(stack.dropLast(1)) } }
        var query by rememberSaveable { mutableStateOf("") }
        var revision by remember { mutableIntStateOf(0) }
        var notice by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        val scope=rememberCoroutineScope()
        fun act(work:suspend ()->Unit) {
            if(busy) return
            busy=true
            scope.launch {
                try { work() } catch(e:Exception) { notice=e.localizedMessage ?: "Ошибка" }
                finally { busy=false }
            }
        }
        LaunchedEffect(callback) {
            val uri=callback ?: return@LaunchedEffect
            try { client.complete(uri); revision++; stack=arrayListOf("catalog","account") }
            catch(e:Exception) { notice=e.localizedMessage ?: "Вход не завершён" }
            callback=null
        }
        BackHandler(stack.size>1) { back() }
        val bar=remember { SnackbarHostState() }
        LaunchedEffect(notice) { if(notice.isNotEmpty()) { bar.showSnackbar(notice); notice="" } }
        fun install(r:JSONObject,pkg:String) = act {
            if(!packageManager.canRequestPackageInstalls()) {
                startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+packageName)))
                notice="После разрешения нажмите кнопку установки ещё раз"
            } else {
                startActivity(client.installer(r,pkg))
            }
        }
        StoreTheme(theme,dynamic) {
            Scaffold(topBar={ TopAppBar(title={ Text(when(page) { "catalog"->"KuizStore"; "account"->"Профиль"; "settings"->"Настройки"; else->if(page.startsWith("apps/")) "Приложение" else "Профиль" }) },
                navigationIcon={ if(stack.size>1) IconButton(onClick={back()}) { Icon(Icons.Rounded.ArrowBack,"Назад") } },
                actions={ IconButton(onClick={go("account")}) { Icon(Icons.Rounded.Person,"Аккаунт") }
                    IconButton(onClick={go("settings")}) { Icon(Icons.Rounded.Settings,"Настройки") } }) },
                snackbarHost={ SnackbarHost(bar) }) { padding ->
                AnimatedContent(page,modifier=Modifier.padding(padding),transitionSpec={
                    if(forward) (slideInHorizontally { it/6 } + fadeIn()) togetherWith fadeOut()
                    else fadeIn() togetherWith (slideOutHorizontally { it/6 } + fadeOut())
                },label="Страница") { screen ->
                    var data by remember(screen) { mutableStateOf<JSONObject?>(null) }
                    var comments by remember(screen) { mutableStateOf(emptyList<JSONObject>()) }
                    var error by remember(screen) { mutableStateOf("") }
                    val term=if(screen=="catalog") query else ""
                    LaunchedEffect(screen,term,revision) {
                        data=null; error=""
                        try {
                            data=when(screen) {
                                "catalog"->{ delay(200); client.api("/apps?q="+Uri.encode(term),auth=false) }
                                "account"->client.api("/session")
                                "settings"->client.api("/self",auth=false)
                                else->client.api("/"+screen)
                            }
                            if(screen.startsWith("apps/")) comments=client.api("/$screen/comments").rows("comments")
                        } catch(e:CancellationException) { throw e } catch(e:Exception) { error=e.localizedMessage ?: "Ошибка загрузки" }
                    }
                    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        if(screen=="catalog") item { OutlinedTextField(query,{query=it.take(60)},singleLine=true,label={Text("Поиск приложений")},modifier=Modifier.fillMaxWidth()) }
                        if(busy || (data==null && error.isEmpty())) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
                        if(error.isNotEmpty()) item { Text(error); TextButton(onClick={revision++}) { Text("Повторить") } }
                        if(screen=="settings") item {
                            Text("Оформление",style=MaterialTheme.typography.titleLarge)
                            Row { listOf("system" to "Система","light" to "Светлая","dark" to "Тёмная").forEach { (v,label)->
                                FilterChip(selected=theme==v,onClick={theme=v;prefs.edit().putString("theme",v).apply()},label={Text(label)})
                            } }
                            Text("Динамические цвета"); Switch(dynamic,{ dynamic=it;prefs.edit().putBoolean("dynamic",it).apply() })
                            data?.takeIf { it.optInt("versionCode")>BuildConfig.VERSION_CODE }?.let { r ->
                                Button(onClick={install(r,packageName)}) { Text("Обновить KuizStore · "+r.optString("versionName")) }
                            }
                        }
                        val obj=data ?: return@LazyColumn
                        val apps=obj.rows("apps")
                        if(screen=="catalog" && apps.isEmpty()) item { Text(if(term.isEmpty()) "Каталог пока пуст" else "Ничего не найдено") }
                        if(screen=="account") item {
                            val me=obj.optJSONObject("me")
                            if(me==null) {
                                Text("Войти через Markol Auth")
                                listOf("google","telegram").forEach { provider -> OutlinedButton(onClick={startActivity(client.login(provider))}) { Text(provider.replaceFirstChar { it.uppercase() }) } }
                            } else {
                                TextButton(onClick={go("users/"+me.getString("nick"))}) { Text(me.getString("display")) }
                                var display by remember(me) { mutableStateOf(me.optString("display")) }
                                var bio by remember(me) { mutableStateOf(me.optString("bio")) }
                                OutlinedTextField(display,{display=it.take(40)},label={Text("Имя")})
                                OutlinedTextField(bio,{bio=it.take(300)},label={Text("О себе")})
                                Button(onClick={act { client.api("/me",JSONObject().put("display",display).put("bio",bio),method="PATCH");revision++ }}) { Text("Сохранить профиль") }
                                OutlinedButton(onClick={act { client.logout(); revision++ }}) { Text("Выйти") }
                            }
                        }
                        if(screen.startsWith("users/")) item {
                            StorePicture(obj.optString("avatar"),72.dp)
                            Text(obj.optString("display"),style=MaterialTheme.typography.headlineMedium)
                            Text("@"+obj.optString("nick")); Text(obj.optString("bio"))
                        }
                        items(apps) { app -> AppRow(app,installedRevision) { go("apps/"+app.getInt("id")) } }
                        if(screen.startsWith("apps/")) {
                            item {
                                StorePicture(obj.optString("icon"),80.dp)
                                Text(obj.getString("name"),style=MaterialTheme.typography.headlineMedium)
                                obj.optJSONObject("author")?.let { author -> TextButton(enabled=author.optString("nick").isNotEmpty(),onClick={go("users/"+author.optString("nick"))}) { Text(author.optString("display")) } }
                                Text(obj.optString("description"))
                                RatingShort(obj.optDouble("rating",0.0),obj.optInt("ratings"))
                                Text("История версий",style=MaterialTheme.typography.titleLarge)
                            }
                            items(obj.rows("screenshots")) { shot ->
                                Picture(SITE+shot.getString("url"),Modifier.fillMaxWidth().height(200.dp),crop=false)
                            }
                            items(obj.rows("releases")) { r ->
                                val pkg=obj.getString("package")
                                val installed=remember(pkg,installedRevision) { runCatching { packageManager.getPackageInfo(pkg,0).versionCode }.getOrNull() }
                                ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
                                    Text(r.getString("version")); Text(r.optString("notes"))
                                    Button(enabled=!busy && Build.VERSION.SDK_INT>=r.optInt("minSdk") && r.getJSONObject("apk").optString("url").isNotEmpty(),onClick={install(r,pkg)}) {
                                        Text(if(installed!=null && installed<r.optInt("versionCode")) "Обновить" else "Установить APK")
                                    }
                                } }
                            }
                            item {
                                Text("Отзывы",style=MaterialTheme.typography.titleLarge)
                                if(obj.has("my_rating")) {
                                    var stars by remember(obj) { mutableIntStateOf(obj.optInt("my_rating")) }
                                    var body by remember(obj) { mutableStateOf(obj.optJSONObject("my_review")?.optString("text").orEmpty()) }
                                    Stars(stars.toDouble(),32.dp) { stars=it }
                                    OutlinedTextField(body,{body=it.take(1000)},label={Text("Ваш отзыв")})
                                    Button(enabled=stars>0 && !busy,onClick={act { client.api("/$screen/comments",JSONObject().put("stars",stars).put("text",body));revision++ }}) { Text("Сохранить") }
                                } else TextButton(onClick={go("account")}) { Text("Войти, чтобы оставить отзыв") }
                            }
                            items(comments) { review ->
                                val author=review.getJSONObject("author")
                                ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
                                    TextButton(onClick={go("users/"+author.getString("nick"))}) { Text(author.getString("display")) }
                                    if(review.optBoolean("can_delete")) TextButton(onClick={act {
                                        client.api("/comments/"+review.getInt("id"),method="DELETE");revision++
                                    }}) { Text("Удалить отзыв") }
                                    Stars(review.optDouble("stars")); Text(review.getString("text"))
                                    review.optJSONObject("reply")?.let { Text("Ответ владельца · "+it.getString("text")) }
                                    Row { listOf(1 to "За",-1 to "Против").forEach { (vote,label) ->
                                        TextButton(onClick={ if(!obj.has("my_rating")) go("account") else act {
                                            client.api("/comments/"+review.getInt("id")+"/vote",JSONObject().put("vote",if(review.optInt("my_vote")==vote) 0 else vote));revision++
                                        } }) { Text(label+" "+review.optInt(if(vote==1) "likes" else "dislikes")) }
                                    } }
                                } }
                            }
                        }
                    }
                }
            }
        }
    }
}
