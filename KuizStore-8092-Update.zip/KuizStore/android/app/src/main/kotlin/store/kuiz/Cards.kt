package store.kuiz
import android.content.pm.PackageManager
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import org.json.JSONObject
@Composable
fun StorePicture(path: String, size: Dp) {
    Picture(if(path.startsWith("/uploads/img/")) SITE+path else "", Modifier.size(size).clip(RoundedCornerShape(28)))
}
@Composable
fun AppRow(card: JSONObject, looked: Int, open: () -> Unit) {

    val context = LocalContext.current
    val installed = remember(card.getString("package"), looked) {
        try {
            context.packageManager.getPackageInfo(card.getString("package"), 0)
            true
        } catch (gone: PackageManager.NameNotFoundException) {
            false
        }
    }
    Card(
        onClick = open,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            StorePicture(card.optString("icon"),64.dp)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(card.getString("name"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (card.optBoolean("official")) {
                        Spacer(Modifier.width(6.dp))
                        Icon(Icons.Rounded.Verified, contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    }
                }
                Text(card.optJSONObject("author")?.optString("display").orEmpty(), style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                val summary = card.optString("summary")
                if (summary.isNotEmpty()) {
                    Text(summary, style = MaterialTheme.typography.bodyMedium, maxLines = 2,
                        overflow = TextOverflow.Ellipsis)
                }
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (card.optInt("ratings") > 0) RatingShort(card.optDouble("rating",0.0))
                    if (card.optString("version").isNotEmpty()) Pill(card.optString("version"), MaterialTheme.colorScheme.surfaceContainerHighest,
                        MaterialTheme.colorScheme.onSurfaceVariant)
                    if (installed) Pill("установлено",
                        MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
        }
    }
}

/** A rating in little room: one star and the number, 4.5 or 5. */
@Composable
fun RatingShort(value: Double, count: Int = 0) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Rounded.Star, contentDescription = null, tint = Color(0xFFFFB300), modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(3.dp))
        val shown = if (value % 1.0 < 0.05 || value % 1.0 > 0.95) "%.0f".format(value) else "%.1f".format(value)
        Text(shown + if (count > 0) " ($count)" else "", style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Five stars; [pick] makes them pressable. */
@Composable
fun Stars(value: Double, size: Dp = 16.dp, pick: ((Int) -> Unit)? = null) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        for (n in 1..5) {
            val full = value >= n - 0.25
            Icon(if (full) Icons.Rounded.Star else Icons.Rounded.StarBorder, contentDescription = null,
                tint = if (full) Color(0xFFFFB300) else MaterialTheme.colorScheme.outline,
                modifier = Modifier.size(size).let { m -> if (pick != null) m.clip(CircleShape).clickable { pick(n) } else m }
                    .padding(if (pick != null) 2.dp else 0.dp))
        }
    }
}

@Composable
fun Pill(text: String, container: Color, content: Color) {
    Text(text, style = MaterialTheme.typography.labelLarge, color = content,
        modifier = Modifier.clip(CircleShape).background(container).padding(horizontal = 12.dp, vertical = 5.dp))
}

