package store.kuiz

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Base64
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.core.content.FileProvider
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

const val SITE = "https://store.markol.fun"
private fun encode(bytes: ByteArray) = Base64.encodeToString(bytes, Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)
private fun nonce() = ByteArray(32).also { SecureRandom().nextBytes(it) }.let(::encode)

class Client(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("login", Context.MODE_PRIVATE)
    private val key: SecretKey by lazy {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        store.getKey("session", null) as? SecretKey ?: KeyGenerator.getInstance("AES", "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder("session", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes("GCM").setEncryptionPaddings("NoPadding").build())
        }.generateKey()
    }
    private fun save(name: String, value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE,key) }
        prefs.edit().putString(name, encode(cipher.iv + cipher.doFinal(value.toByteArray()))).commit()
    }
    private fun read(name: String): String? {
        val raw = prefs.getString(name,null) ?: return null
        val bytes = Base64.decode(raw,Base64.URL_SAFE)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE,key,GCMParameterSpec(128,bytes,0,12))
        return String(cipher.doFinal(bytes,12,bytes.size-12), Charsets.UTF_8)
    }
    fun login(provider: String): Intent {
        val verifier = nonce()
        val state = nonce()
        save("pending","$state.$verifier")
        val challenge = encode(MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray()))
        return Intent(Intent.ACTION_VIEW,Uri.parse("$SITE/api/android/login/$provider?state=$state&challenge=$challenge"))
    }
    suspend fun complete(uri: Uri) {
        require(uri.scheme=="kuizstore" && uri.host=="login" && uri.path=="/complete")
        val pending = read("pending")?.split('.') ?: error("Вход устарел")
        require(uri.getQueryParameter("state")==pending.first()) { "Неверный state" }
        prefs.edit().remove("pending").commit()
        val result = api("/android/exchange",JSONObject().put("code",uri.getQueryParameter("code")).put("verifier",pending.last()),false)
        save("token",result.getString("token"))
    }
    suspend fun logout() {
        api("/auth/logout",JSONObject())
        prefs.edit().remove("token").commit()
    }
    suspend fun api(path: String, body: JSONObject? = null, auth: Boolean = true, method: String = if(body==null) "GET" else "POST"): JSONObject = withContext(Dispatchers.IO) {
        val conn = URL("$SITE/api$path").openConnection() as HttpURLConnection
        try {
            conn.instanceFollowRedirects=false
            conn.connectTimeout=15000
            conn.readTimeout=30000
            if(auth) read("token")?.let { conn.setRequestProperty("Authorization","Bearer $it") }
            conn.requestMethod=method
            if(body!=null) {
                conn.doOutput=true
                conn.setRequestProperty("Content-Type","application/json")
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
            }
            if(conn.responseCode==401 && auth) prefs.edit().remove("token").commit()
            if(conn.responseCode !in 200..299) error("KuizStore HTTP ${conn.responseCode}")
            JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
        } finally { conn.disconnect() }
    }
    suspend fun installer(release: JSONObject, pkg: String): Intent = withContext(Dispatchers.IO) {
        val apk = release.getJSONObject("apk")
        val path = apk.getString("url")
        require(Regex("/api/download/[0-9]+").matches(path))
        val dir = File(ctx.cacheDir,"releases").apply { mkdirs() }
        val file = File.createTempFile("release-", ".apk",dir)
        val conn = URL(SITE+path).openConnection() as HttpURLConnection
        try {
            conn.instanceFollowRedirects=false
            conn.connectTimeout=15000
            conn.readTimeout=60000
            require(conn.responseCode==200)
            val digest = MessageDigest.getInstance("SHA-256")
            val expected = apk.getLong("size")
            require(expected in 1..419430400L)
            conn.inputStream.use { input -> file.outputStream().use { output ->
                val buffer=ByteArray(65536)
                var total=0L
                while(true) {
                    val n=input.read(buffer)
                    if(n<0) break
                    total+=n
                    require(total<=expected)
                    digest.update(buffer,0,n)
                    output.write(buffer,0,n)
                }
                require(total==expected)
            } }
            require(digest.digest().joinToString("") { "%02x".format(it) } == apk.getString("sha256")) { "Контрольная сумма APK не совпала" }
            require(ctx.packageManager.getPackageArchiveInfo(file.path,0)?.packageName==pkg)
            val uri = FileProvider.getUriForFile(ctx,ctx.packageName+".files",file)
            Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch(e: Exception) { file.delete(); throw e } finally { conn.disconnect() }
    }
}
