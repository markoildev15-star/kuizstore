import base64,hashlib,http.client,io,json,os,sqlite3,sys,tempfile,threading,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
import store

class StoreTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
  store._local=threading.local();store.DB=str(self.root/'test.db');store.FILES=str(self.root/'files')
  store.ALLOWLIST=str(self.root/'allow.json');store.CONTRACT=str(self.root/'contract.json')
  Path(store.ALLOWLIST).write_text('["google:owner"]')
  Path(store.CONTRACT).write_text(json.dumps(dict(verified_contract=True,project_user_id=True)))
  store.SESSION_KEY="s"*40;store.initialize()
  for nick,identity in [('owner','google:owner'),('reader','google:reader')]:
   store.db().execute('INSERT INTO users(nick,identity,created) VALUES(?,?,?)',(nick,identity,store.now()))
  store.db().commit()
  self.tokens={n:store.new_session(i) for n,i in [('owner',1),('reader',2)]}
  self.csrf={n:store.db().execute('SELECT csrf FROM sessions WHERE user_id=?',(i,)).fetchone()[0] for n,i in [('owner',1),('reader',2)]}
  self.server=store.ThreadingHTTPServer(('127.0.0.1',0),store.Handler); self.server.daemon_threads=True
  self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
 def tearDown(self):
  self.server.shutdown();self.server.server_close();self.thread.join();store.db().close();self.tmp.cleanup()
 def req(self,path,method='GET',body=None,user=None,csrf=True,headers=None):
  h={}
  if user:
   h['Cookie']='__Host-kuiz='+self.tokens[user]
   if csrf:h.update({'Origin':store.ORIGIN,'X-CSRF-Token':self.csrf[user]})
  h.update(headers or {})
  if body is not None: body=json.dumps(body);h['Content-Type']='application/json'
  c=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=5);c.request(method,path,body,h)
  r=c.getresponse();raw=r.read();out=json.loads(raw) if raw and not raw.startswith(b'<!') else raw.decode(); result=(r.status,out,dict(r.getheaders()));c.close();return result
 def create_app(self):
  status,a,_=self.req('/api/apps','POST',dict(name='Demo',package='fun.example.demo',git='https://example.com'),user='owner');self.assertEqual(status,200,a)
  store.db().execute("UPDATE apps SET status='approved' WHERE id=?",(a['id'],));store.db().commit();return a['id']
 def test_guest_catalog_search_and_hidden(self):
  aid=self.create_app();self.assertEqual(len(self.req('/api/apps?q=Demo')[1]['apps']),1)
  self.assertEqual(self.req('/api/apps/'+str(aid))[0],200)
  self.req('/api/admin/apps/'+str(aid),'POST',dict(action='hide'),user='owner')
  self.assertEqual(self.req('/api/apps/'+str(aid))[0],404)
 def test_every_admin_handler_rejects_reader(self):
  for method,pattern,handler in store.ROUTES:
   if handler not in store.ADMIN_HANDLERS:continue
   path=pattern.replace(r'(\d+)','1').replace('(icon|cover)','icon')
   self.assertEqual(self.req('/api'+path,method,{},'reader')[0],403,path)
 def test_csrf_and_stale_bearer(self):
  self.assertEqual(self.req('/api/me','PATCH',{'bio':'no'},'reader',False)[0],403)
  self.assertEqual(self.req('/api/me',headers={'Authorization':'Bearer '+self.tokens['reader']})[0],401)
 def test_review_edit_vote_delete(self):
  aid=self.create_app();path=f'/api/apps/{aid}/comments'
  self.assertEqual(self.req(path,'POST',{'text':'Great','stars':5},'reader')[0],200)
  self.req(path,'POST',{'text':'Edited','stars':4},'reader')
  comments=self.req(path)[1]['comments'];self.assertEqual(len(comments),1);self.assertEqual(comments[0]['text'],'Edited')
  cid=comments[0]['id'];self.assertEqual(self.req(f'/api/comments/{cid}/vote','POST',{'vote':1},'owner')[0],200)
  self.assertEqual(self.req(f'/api/comments/{cid}','DELETE',{},'reader')[0],200)
  self.assertEqual(self.req(path)[1]['comments'],[])
 def test_removed_routes(self):
  for p in ['/chats','/badges','/auth/google/start','/auth/telegram','/me/apps','/admin/badges']:
   for method in ['GET','POST']:
    self.assertEqual(self.req('/api'+p,method,{},'owner')[0],404)
 def test_empty_allowlist_and_unverified_identity(self):
  Path(store.ALLOWLIST).write_text('[]');self.assertEqual(self.req('/api/admin/users',user='owner')[0],403)
  with self.assertRaises(store.Refusal):store.identity_of({'test_provider':'google','test_sub':'owner','test_verified':False},'google')
  self.assertEqual(store.identity_of({'user_id':'123'},'google'),store.identity_of({'user_id':'123'},'telegram'))
 def test_oauth_two_providers_state_replay_pkce(self):
  from urllib.parse import urlparse,parse_qs
  for provider in ['google','telegram']:
   with patch.multiple(store,CLIENT='test-client',SECRET='test-secret',SESSION_KEY='s'*40):
    s,_,h=self.req('/login/'+provider);self.assertEqual(s,302)
    query=parse_qs(urlparse(h['Location']).query);self.assertEqual(query['code_challenge_method'],['S256'])
    cookie=h['Set-Cookie'].split(';')[0];state=query['state'][0]
    self.assertEqual(self.req('/auth/callback?state=forged&code=abc',headers={'Cookie':cookie})[0],400)
    def fake(path,token=None,data=None):
     if path=='/oauth/token':
      challenge=base64.urlsafe_b64encode(hashlib.sha256(data['code_verifier'].encode()).digest()).rstrip(b'=').decode()
      self.assertEqual(challenge,query['code_challenge'][0]);return {'access_token':'test'}
     if path=='/oauth/userinfo':return {'user_id':'123'}
     return {}
    with patch.object(store,'auth_json',side_effect=fake):
     s,_,h=self.req('/auth/callback?state='+state+'&code=abc',headers={'Cookie':cookie});self.assertEqual(s,302)
     self.assertIn('HttpOnly',h['Set-Cookie']);self.assertIn('Secure',h['Set-Cookie'])
     self.assertEqual(self.req('/auth/callback?state='+state+'&code=abc',headers={'Cookie':cookie})[0],400)
 def test_android_exchange(self):
  from urllib.parse import urlparse,parse_qs
  verifier='v'*43
  challenge=base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b'=').decode()
  state='s'*43
  with patch.multiple(store,CLIENT='project',SECRET='test-secret'), patch.object(store,'auth_json',side_effect=[{'access_token':'upstream'},{'user_id':42},{}]):
   status,_,h=self.req('/api/android/login/google?challenge='+challenge+'&state='+state)
   self.assertEqual(status,302)
   gateway_state=parse_qs(urlparse(h['Location']).query)['state'][0]
   status,_,h=self.req('/auth/callback?state='+gateway_state+'&code=gateway',headers={'Cookie':h['Set-Cookie'].split(';')[0]})
   self.assertEqual(status,302)
   self.assertTrue(h['Location'].startswith('kuizstore://login/complete?'))
   args=parse_qs(urlparse(h['Location']).query)
   self.assertEqual(args['state'],[state])
   exchange='/api/android/exchange'
   body=dict(code=args['code'][0],verifier=verifier)
   self.assertEqual(self.req(exchange,'POST',body|{'verifier':'x'*43})[0],403)
   status,obj,_=self.req(exchange,'POST',body)
   self.assertEqual(status,200)
   self.assertEqual(self.req(exchange,'POST',body)[0],403)
   headers={'Authorization':'Bearer '+obj['token']}
   self.assertEqual(self.req('/api/me',headers=headers)[0],200)
   Path(store.ALLOWLIST).write_text('["markol:project:42"]')
   self.assertEqual(self.req('/api/apps','POST',{},headers=headers)[0],403)
   self.assertEqual(self.req('/api/auth/logout','POST',{},headers=headers)[0],200)
   self.assertEqual(self.req('/api/me',headers=headers)[0],401)
 def test_logout_revokes(self):
  self.assertEqual(self.req('/api/auth/logout','POST',{},'reader')[0],200)
  self.assertEqual(self.req('/api/me',user='reader')[0],401)
 def test_invalid_apk_cannot_publish(self):
  aid=self.create_app();rid=self.req(f'/api/apps/{aid}/releases','POST',{'version':'1'},'owner')[1]['id']
  h={'Cookie':'__Host-kuiz='+self.tokens['owner'],'Origin':store.ORIGIN,'X-CSRF-Token':self.csrf['owner']}
  c=http.client.HTTPConnection('127.0.0.1',self.server.server_port);c.request('POST',f'/api/releases/{rid}/file',b'not apk',h)
  r=c.getresponse();self.assertEqual(r.status,415);r.read();c.close()
 def test_upload_signature_version_checks(self):
  aid=self.create_app()
  import apk
  def upload(version,code,signer):
   rid=self.req(f'/api/apps/{aid}/releases','POST',{'version':version},'owner')[1]['id']
   with patch.object(apk,'inspect_apk',return_value=dict(package='fun.example.demo',version=version,version_code=code,min_sdk=26,signer=signer)):
    c=http.client.HTTPConnection('127.0.0.1',self.server.server_port)
    c.request('POST',f'/api/releases/{rid}/file',b'PK\x03\x04fake-for-mock',{'Cookie':'__Host-kuiz='+self.tokens['owner'],'Origin':store.ORIGIN,'X-CSRF-Token':self.csrf['owner']})
    r=c.getresponse();status=r.status;r.read();c.close();return status
  self.assertEqual(upload('1',1,'a'),200)
  self.assertEqual(upload('2',2,'b'),409)
  self.assertEqual(upload('1',1,'a'),409)
  self.assertEqual(upload('2',2,'a'),200)
 def test_expired_session_and_publish_requires_apk(self):
  store.db().execute('UPDATE sessions SET created=0 WHERE user_id=2');store.db().commit()
  self.assertEqual(self.req('/api/me',user='reader')[0],401)
  s,a,_=self.req('/api/apps','POST',dict(name='Draft',package='fun.example.draft'),'owner')
  self.assertEqual(s,200)
  self.assertEqual(self.req('/api/admin/apps/'+str(a['id']),'POST',{'action':'approve'},'owner')[0],409)
 def test_images_screenshots_and_soft_delete(self):
  from PIL import Image
  aid=self.create_app()
  buf=io.BytesIO();Image.new('RGB',(12,12),'green').save(buf,format='PNG')
  def raw(path,data):
   c=http.client.HTTPConnection('127.0.0.1',self.server.server_port)
   c.request('POST',path,data,{'Cookie':'__Host-kuiz='+self.tokens['owner'],'Origin':store.ORIGIN,'X-CSRF-Token':self.csrf['owner']})
   r=c.getresponse();status=r.status;out=json.loads(r.read());c.close();return status,out
  self.assertEqual(raw(f'/api/apps/{aid}/screenshots',buf.getvalue())[0],200)
  shots=self.req(f'/api/apps/{aid}',user='owner')[1]['screenshots'];self.assertEqual(len(shots),1)
  self.assertEqual(raw('/api/me/avatar',b'\x89PNGmalformed')[0],415)
  self.assertEqual(self.req('/api/screenshots/'+str(shots[0]['id']),'DELETE',{},'owner')[0],200)
  self.assertEqual(self.req('/api/apps/'+str(aid),'DELETE',{},'owner')[0],200)
  self.assertEqual(self.req('/api/apps/'+str(aid))[0],404)
 def test_no_credential_or_user_input_xss_in_server_html(self):
  self.assertEqual(self.req('/admin',user='reader')[0],403)
  self.assertEqual(self.req('/admin')[0],401)
  self.assertEqual(self.req('/admin',user='owner')[0],200)
 def test_oauth_wrong_browser_and_expired_attempt(self):
  from urllib.parse import urlparse,parse_qs
  with patch.multiple(store,CLIENT='test-client',SECRET='test-secret',SESSION_KEY='s'*40):
   status,_,h=self.req('/login/google');self.assertEqual(status,302)
   state=parse_qs(urlparse(h['Location']).query)['state'][0]
   self.assertEqual(self.req('/auth/callback?state='+state+'&code=x')[0],400)
   store.db().execute('UPDATE oauth_attempts SET created=0');store.db().commit()
   self.assertEqual(self.req('/auth/callback?state='+state+'&code=x',headers={'Cookie':h['Set-Cookie'].split(';')[0]})[0],400)

class MigrationTests(unittest.TestCase):
 def test_backup_and_preserve_catalog(self):
  from migrate import migrate
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'legacy.db'
   with sqlite3.connect(p) as c:
    c.executescript("CREATE TABLE users(id INTEGER PRIMARY KEY,nick TEXT,created INTEGER); INSERT INTO users VALUES(1,'old',1);")
   result=migrate(p)
   self.assertTrue(Path(result['backup']).exists());self.assertEqual(result['copied']['users'],1)
   with sqlite3.connect(result['migrated']) as c:
    self.assertEqual(c.execute('SELECT nick,identity FROM users').fetchone(),('old',None))

if __name__=='__main__':unittest.main()
