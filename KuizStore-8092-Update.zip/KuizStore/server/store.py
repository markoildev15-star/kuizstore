"""KuizStore. Fork of MargyStore, GPL-3.0-or-later. See NOTICE.md."""
import base64, hashlib, hmac, json, os, re, secrets, sqlite3, sys, threading, time
import urllib.parse, urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from pathlib import Path
HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.getenv("KUIZ_DB", os.path.join(HERE, "store.db"))
FILES = os.getenv("KUIZ_FILES", os.path.join(HERE, "files"))
PUBLIC_FILES = "/uploads/"
IMAGE_MOST = 3 << 20
APK_MOST = 400 << 20
NICK = re.compile(r"^[a-zA-Z0-9_.]{3,20}$")
LANGS = ("ru", "uk", "en", "kk")
_local = threading.local()
def db():
    link = getattr(_local, "link", None)
    if link is None:
        link = sqlite3.connect(DB, timeout=15)
        link.row_factory = sqlite3.Row
        link.execute("PRAGMA journal_mode=WAL")
        link.execute("PRAGMA foreign_keys=ON")
        _local.link = link
    return link

def now():
    return int(time.time())

class Refusal(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code
        self.message = message

def refuse(code, message):
    raise Refusal(code, message)

def limited(what, most, within):
    """True when `what` has happened `most` times within `within` seconds already."""
    link = db()
    t = now()
    link.execute("DELETE FROM knocks WHERE at < ?", (t - 86400,))
    many = link.execute("SELECT COUNT(*) FROM knocks WHERE what = ? AND at > ?", (what, t - within)).fetchone()[0]
    if many >= most:
        link.commit()
        return True
    link.execute("INSERT INTO knocks (what, at) VALUES (?, ?)", (what, t))
    link.commit()
    return False

def new_session(user_id):
    token = secrets.token_urlsafe(32)
    db().execute('DELETE FROM sessions WHERE created<?',(now()-604800,))
    db().execute("INSERT INTO sessions (token_hash, user_id, created, seen, csrf) VALUES (?, ?, ?, ?, ?)",
                 (token_hash(token), user_id, now(), now(), secrets.token_urlsafe(32)))
    db().commit()
    return token

def file_url(path):
    return (PUBLIC_FILES + path) if re.fullmatch(r"img/[a-f0-9]+\.(png|jpg|webp)", path or "") else ""

def tr_of(raw):
    try:
        said = json.loads(raw or "{}")
        return said if isinstance(said, dict) else {}
    except ValueError:
        return {}

def tr_take(value, most, field):
    """A text in several languages, as given: only the store's languages, each cut to size."""
    if not isinstance(value, dict):
        refuse(400, "%s: нужен словарь языков" % field)
    return {lang: text(value.get(lang, ""), most, field) for lang in LANGS if str(value.get(lang, "")).strip()}

def buttons_take(value):
    """The app's own buttons: a link each, or a window of text."""
    if not isinstance(value, list) or len(value) > 8:
        refuse(400, "кнопок не больше восьми")
    out = []
    for item in value:
        if not isinstance(item, dict):
            refuse(400, "непонятная кнопка")
        title = text(item.get("title"), 30, "кнопка")
        url = text(item.get("url"), 300, "ссылка")
        words = text(item.get("text"), 4000, "текст кнопки")
        if not title or not (url or words):
            refuse(400, "у кнопки нужно название и ссылка или текст")
        if url and not re.match(r"^(https://|tg://|mailto:)", url):
            refuse(400, "ссылка кнопки должна начинаться с https://")
        out.append({"title": title, "url": url} if url else {"title": title, "text": words})
    return out

def rating_of(app_id):
    row = db().execute("SELECT AVG(stars) a, COUNT(*) n FROM ratings WHERE app_id = ?", (app_id,)).fetchone()
    return round(row["a"] or 0, 2), row["n"]

def app_card(row):
    owner = db().execute("SELECT * FROM users WHERE id = ?", (row["owner_id"],)).fetchone() if row["owner_id"] else None
    stars, many = rating_of(row["id"])
    latest = db().execute("SELECT version FROM releases WHERE app_id = ? AND status = 'approved' AND beta = 0 "
                          "ORDER BY id DESC LIMIT 1", (row["id"],)).fetchone()
    return {"id": row["id"], "slug": row["slug"], "name": row["name"], "summary": row["summary"],
            "summary_tr": tr_of(row["tr"]).get("summary", {}),
            "icon": file_url(row["icon"]), "cover": file_url(row["cover"]), "package": row["package"],
            "official": bool(row["official"]), "author": user_card(owner) if owner else {"nick": "", "display": row["author"] or "KuizStore", "avatar": ""},
            "rating": stars, "ratings": many, "version": latest["version"] if latest else "", "status": row["status"]}

def free_nick(name):
    base = re.sub(r"[^a-zA-Z0-9_.]", "", (name or "").split("@")[0])[:16]
    if len(base) < 3:
        base = "user"
    link = db()
    nick = base
    while link.execute("SELECT 1 FROM users WHERE nick = ?", (nick,)).fetchone():
        nick = "%s%d" % (base, secrets.randbelow(9000) + 1000)
    return nick

def save_upload(stream, length, kind, most):
    if length <= 0:
        refuse(400, "пустой файл")
    if length > most:
        refuse(413, "файл слишком большой")
    first = stream.read(min(length, 16))
    if kind == "image":
        if first.startswith(b"\x89PNG"):
            ext = "png"
        elif first.startswith(b"\xff\xd8\xff"):
            ext = "jpg"
        elif first[:4] == b"RIFF" and first[8:12] == b"WEBP":
            ext = "webp"
        else:
            refuse(415, "нужна картинка PNG, JPEG или WebP")
        folder = "img"
    else:
        if not first.startswith(b"PK\x03\x04"):
            refuse(415, "это не apk")
        ext = "apk"
        folder = "apk"
    name = "%s/%s.%s" % (folder, secrets.token_hex(12), ext)
    path = os.path.join(FILES, name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    digest = hashlib.sha256(first)
    left = length - len(first)
    with open(path + ".part", "wb") as out:
        out.write(first)
        while left > 0:
            block = stream.read(min(1 << 16, left))
            if not block:
                break
            out.write(block)
            digest.update(block)
            left -= len(block)
    if left:
        os.remove(path + ".part")
        refuse(400, "файл пришёл не целиком")
    os.replace(path + ".part", path)
    if kind == "image":
        from images import sanitize
        try: sanitize(path)
        except Exception:
            os.remove(path)
            raise
        return name, hashlib.sha256(Path(path).read_bytes()).hexdigest(), os.path.getsize(path)
    return name, digest.hexdigest(), length

def forget_file(name):
    if name and re.fullmatch(r"(?:img|apk)/[a-f0-9]+\.(?:png|jpg|webp|apk)", name):
        try:
            os.remove(os.path.join(FILES, name))
        except OSError:
            pass

class Handler(BaseHTTPRequestHandler):
    server_version = "KuizStore"

    def setup(self):
        super().setup()
        self.connection.settimeout(60)

    def log_message(self, *args):
        pass

    def who(self):
        if os.getenv('TRUST_LOCAL_PROXY') == '1' and self.client_address[0] in ('127.0.0.1','::1'):
            return self.headers.get('X-Real-IP') or self.client_address[0]
        return self.client_address[0]

    def answer(self, code, body):
        page = isinstance(body, dict) and "__html__" in body
        data = body["__html__"].encode() if page else json.dumps(body, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8" if page else "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        for key, value in getattr(self, "extra_headers", []):
            self.send_header(key, value)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(data)

    def body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length > 64 * 1024:
            refuse(413, "слишком длинный запрос")
        if length <= 0:
            return {}
        try:
            said = json.loads(self.rfile.read(length))
        except Exception:
            refuse(400, "непонятный запрос")
        if not isinstance(said, dict):
            refuse(400, "непонятный запрос")
        return said

    def route(self, method):
        parts = urllib.parse.urlparse(self.path)
        path = parts.path.rstrip("/") or "/"
        query = {k: v[0] for k, v in urllib.parse.parse_qs(parts.query).items()}
        return dispatch(self, method, path, query)
    def run(self, method):
        self.extra_headers = []
        try:
            code, out = self.route(method)
        except Refusal as no:
            db().rollback()
            code, out = no.code, {"error": no.message}
        except (ValueError, TypeError):
            db().rollback()
            code, out = 400, {"error": "invalid request"}
        except Exception as broken:
            db().rollback()
            print("request failed:", type(broken).__name__, flush=True)
            code, out = 500, {"error": "ошибка на сервере"}
        self.answer(code, out)

    def do_GET(self):
        self.run("GET")

    def do_POST(self):
        # Android's HttpURLConnection cannot send PATCH: it is said in a header instead
        override = (self.headers.get("X-HTTP-Method-Override") or "").upper()
        self.run(override if override in ("PATCH", "PUT", "DELETE") else "POST")

    def do_PATCH(self):
        self.run("PATCH")

    def do_PUT(self):
        self.run("PUT")

    def do_DELETE(self):
        self.run("DELETE")

def need(user):
    if user is None:
        refuse(401, "нужно войти")
    return user

def need_admin(user):
    if not is_admin(need(user)):
        refuse(403, "только для админа")
    return user

def text(value, most, field):
    value = str(value or "").strip()
    if len(value) > most:
        refuse(400, "%s: слишком длинно" % field)
    return value

def me(h, user, q):
    return 200, me_view(need(user))

def me_edit(h, user, q):
    user = need(user)
    said = h.body()
    link = db()
    if "nick" in said:
        nick = str(said["nick"])
        if not NICK.fullmatch(nick):
            refuse(400, "ник: 3–20 знаков, латиница, цифры, _ и .")
        taken = link.execute("SELECT id FROM users WHERE nick = ?", (nick,)).fetchone()
        if taken and taken["id"] != user["id"]:
            refuse(409, "такой ник уже занят")
        link.execute("UPDATE users SET nick = ?, nick_set = 1 WHERE id = ?", (nick, user["id"]))
    if "display" in said:
        link.execute("UPDATE users SET display = ? WHERE id = ?", (text(said["display"], 40, "имя"), user["id"]))
    if "bio" in said:
        link.execute("UPDATE users SET bio = ? WHERE id = ?", (text(said["bio"], 300, "о себе"), user["id"]))
    link.commit()
    return 200, me_view(link.execute("SELECT * FROM users WHERE id = ?", (user["id"],)).fetchone())

def me_avatar(h, user, q):
    user = need(user)
    name, _, _ = save_upload(h.rfile, int(h.headers.get("Content-Length") or 0), "image", IMAGE_MOST)
    forget_file(user["avatar"])
    db().execute("UPDATE users SET avatar = ? WHERE id = ?", (name, user["id"]))
    db().commit()
    return 200, {"avatar": file_url(name)}

def people(h, user, q):
    term = text(q.get("q", ""), 40, "поиск")
    rows = db().execute("SELECT * FROM users WHERE nick LIKE ? OR display LIKE ? ORDER BY nick LIMIT 30",
                        ("%" + term + "%", "%" + term + "%")).fetchall()
    return 200, {"users": [user_card(r) for r in rows]}

def fix_icon(card, row):
    card["icon"] = icon_url(row["icon"])
    return card

def app(h, user, q, app_id):
    row = app_row(int(app_id), user)
    out = fix_icon(app_card(row), row)
    mine = is_admin(user)
    out.update({"description": row["description"], "description_tr": tr_of(row["tr"]).get("description", {}),
                "buttons": json.loads(row["buttons"] or "[]"),
                "git": row["git"], "license": row["license"],
                "detect": row["detect"], "note": row["note"], "can_edit": mine,
                "releases": visible_releases(row, user, all_of_them=mine),
                "screenshots": [{"id": r["id"], "url": file_url(r["file"])} for r in db().execute("SELECT * FROM screenshots WHERE app_id=? ORDER BY id",(row["id"],))]})
    if user is not None:
        mine_stars = db().execute("SELECT stars FROM ratings WHERE app_id = ? AND user_id = ?", (row["id"], user["id"])).fetchone()
        out["my_rating"] = mine_stars["stars"] if mine_stars else 0
        out["my_review"] = my_review(row["id"], user)
    return 200, out

def app_edit(h, user, q, app_id):
    row = app_row(int(app_id), need(user), edit=True)
    said = h.body()
    if "git" in said: said["git"] = safe_url(said["git"])
    fields = {"name": 40, "summary": 140, "description": 6000, "git": 300, "license": 60}
    link = db()
    for field, most in fields.items():
        if field in said:
            link.execute("UPDATE apps SET %s = ?, updated = ? WHERE id = ?" % field, (text(said[field], most, field), now(), row["id"]))
    tr = tr_of(row["tr"])
    for field, most in (("summary", 140), ("description", 6000)):
        if field + "_tr" in said:
            tr[field] = tr_take(said[field + "_tr"], most, field)
    link.execute("UPDATE apps SET tr = ? WHERE id = ?", (json.dumps(tr, ensure_ascii=False), row["id"]))
    if "buttons" in said:
        link.execute("UPDATE apps SET buttons = ? WHERE id = ?",
                     (json.dumps(buttons_take(said["buttons"]), ensure_ascii=False), row["id"]))
    link.commit()
    return app(h, user, q, app_id)

def app_picture(h, user, q, app_id, which):
    row = app_row(int(app_id), need(user), edit=True)
    name, _, _ = save_upload(h.rfile, int(h.headers.get("Content-Length") or 0), "image", IMAGE_MOST)
    column = "icon" if which == "icon" else "cover"
    if not row[column].startswith("builtin:"):
        forget_file(row[column])
    db().execute("UPDATE apps SET %s = ?, updated = ? WHERE id = ?" % column, (name, now(), row["id"]))
    db().commit()
    return 200, {column: file_url(name)}

def release_new(h, user, q, app_id):
    row = app_row(int(app_id), need(user), edit=True)
    said = h.body()
    version = text(said.get("version"), 40, "версия")
    if not version:
        refuse(400, "нужна версия")
    link = db()
    notes_tr = tr_take(said.get("notes_tr") or {}, 3000, "что нового")
    link.execute("INSERT INTO releases (app_id, version, notes, beta, status, kind, notes_tr, created) "
                 "VALUES (?, ?, ?, ?, 'draft', 'apk', ?, ?)",
                 (row["id"], version, text(said.get("notes"), 3000, "что нового"), int(bool(said.get("beta"))),
                  json.dumps(notes_tr, ensure_ascii=False), now()))
    link.commit()
    return 200, {"id": link.execute("SELECT MAX(id) FROM releases WHERE app_id = ?", (row["id"],)).fetchone()[0]}

def comments(h, user, q, app_id):
    app = app_row(int(app_id), user)
    # the app's maker: their answer and their like are told apart from everybody's
    maker = db().execute("SELECT * FROM users WHERE id = ?", (app["owner_id"],)).fetchone() if app["owner_id"] else None
    answers = user is not None and ((maker is not None and user["id"] == maker["id"]) or is_admin(user))
    top = q.get("sort") == "top"
    skip = max(0, int(q.get("offset") or 0))
    rows = db().execute(
        "SELECT c.*, COALESCE(SUM(CASE WHEN v.vote > 0 THEN 1 END), 0) likes, "
        "COALESCE(SUM(CASE WHEN v.vote < 0 THEN 1 END), 0) dislikes "
        "FROM comments c LEFT JOIN comment_votes v ON v.comment_id = c.id "
        "WHERE c.app_id = ? AND c.deleted = 0 GROUP BY c.id ORDER BY %s LIMIT 30 OFFSET ?"
        % ("c.pinned DESC, likes - dislikes DESC, c.id DESC" if top else "c.pinned DESC, c.id DESC"),
        (int(app_id), skip)).fetchall()
    out = []
    for r in rows:
        author = db().execute("SELECT * FROM users WHERE id = ?", (r["user_id"],)).fetchone()
        stars = db().execute("SELECT stars FROM ratings WHERE app_id = ? AND user_id = ?", (int(app_id), r["user_id"])).fetchone()
        mine = db().execute("SELECT vote FROM comment_votes WHERE comment_id = ? AND user_id = ?",
                            (r["id"], user["id"])).fetchone() if user is not None else None
        felt = db().execute("SELECT vote FROM comment_votes WHERE comment_id = ? AND user_id = ?",
                            (r["id"], maker["id"])).fetchone() if maker is not None and maker["id"] != r["user_id"] else None
        out.append({"id": r["id"], "text": r["text"], "created": r["created"], "edited": r["edited"], "author": user_card(author),
                    "maker_vote": felt["vote"] if felt else 0,
                    "reply": {"text": r["reply"], "created": r["replied"], "author": user_card(maker) if maker else
                              {"nick": "", "display": app["author"] or "KuizStore", "avatar": ""}} if r["reply"] else None,
                    "can_reply": answers,
                    "stars": stars["stars"] if stars else 0, "likes": r["likes"], "dislikes": r["dislikes"],
                    "my_vote": mine["vote"] if mine else 0, "pinned": bool(r["pinned"]), "can_pin": is_owner(user),
                    "can_delete": user is not None and (user["id"] == r["user_id"] or is_admin(user))})
    return 200, {"comments": out}

def comment_reply(h, user, q, comment_id):
    """The app's maker answers a review; an empty answer takes it back."""
    user = need(user)
    row = db().execute("SELECT * FROM comments WHERE id = ? AND deleted = 0", (int(comment_id),)).fetchone()
    if row is None:
        refuse(404, "нет такого отзыва")
    app = db().execute("SELECT * FROM apps WHERE id = ?", (row["app_id"],)).fetchone()
    if app["owner_id"] != user["id"] and not is_admin(user):
        refuse(403, "отвечать может только автор приложения")
    words = text(h.body().get("text"), 1000, "ответ")
    db().execute("UPDATE comments SET reply = ?, replied = ? WHERE id = ?", (words, now() if words else 0, row["id"]))
    db().commit()
    return 200, {}

def comment_pin(h, user, q, comment_id):
    if not is_owner(user):
        refuse(403, "закреплять может только владелец")
    pinned = int(bool(h.body().get("pinned", True)))
    db().execute("UPDATE comments SET pinned = ? WHERE id = ?", (pinned, int(comment_id)))
    db().commit()
    return 200, {"pinned": bool(pinned)}

def comment_vote(h, user, q, comment_id):
    user = need(user)
    row = db().execute("SELECT * FROM comments WHERE id = ? AND deleted = 0", (int(comment_id),)).fetchone()
    if row is None:
        refuse(404, "нет такого комментария")
    vote = int(h.body().get("vote") or 0)
    if vote == 0:
        db().execute("DELETE FROM comment_votes WHERE comment_id = ? AND user_id = ?", (row["id"], user["id"]))
    else:
        db().execute("INSERT INTO comment_votes (comment_id, user_id, vote) VALUES (?, ?, ?) "
                     "ON CONFLICT (comment_id, user_id) DO UPDATE SET vote = excluded.vote",
                     (row["id"], user["id"], 1 if vote > 0 else -1))
    db().commit()
    counts = db().execute("SELECT COALESCE(SUM(vote > 0), 0), COALESCE(SUM(vote < 0), 0) FROM comment_votes "
                          "WHERE comment_id = ?", (row["id"],)).fetchone()
    return 200, {"likes": counts[0], "dislikes": counts[1], "my_vote": vote and (1 if vote > 0 else -1)}

def comment_new(h, user, q, app_id):
    """The person's review of an app: one each, written anew or changed, and its stars are their rating."""
    user = need(user)
    app_row(int(app_id), user)
    said = h.body()
    words = text(said.get("text"), 1000, "отзыв")
    stars = int(said.get("stars") or 0)
    if stars < 1 or stars > 5:
        refuse(400, "поставьте оценку от 1 до 5 звёзд")
    if limited("comment:%d" % user["id"], 10, 600):
        refuse(429, "слишком часто, подождите немного")
    link = db()
    mine = link.execute("SELECT id FROM comments WHERE app_id = ? AND user_id = ? AND deleted = 0",
                        (int(app_id), user["id"])).fetchone()
    if mine:
        link.execute("UPDATE comments SET text = ?, edited = ? WHERE id = ?", (words, now(), mine["id"]))
    else:
        link.execute("INSERT INTO comments (app_id, user_id, text, created) VALUES (?, ?, ?, ?)",
                     (int(app_id), user["id"], words, now()))
    link.execute("INSERT INTO ratings (app_id, user_id, stars, updated) VALUES (?, ?, ?, ?) "
                 "ON CONFLICT (app_id, user_id) DO UPDATE SET stars = excluded.stars, updated = excluded.updated",
                 (int(app_id), user["id"], stars, now()))
    link.commit()
    return 200, {"my_review": my_review(int(app_id), user)}

def my_review(app_id, user):
    row = db().execute("SELECT c.id, c.text, c.created, c.edited, r.stars FROM comments c LEFT JOIN ratings r "
                       "ON r.app_id = c.app_id AND r.user_id = c.user_id WHERE c.app_id = ? AND c.user_id = ? "
                       "AND c.deleted = 0", (app_id, user["id"])).fetchone()
    if row is None:
        return None
    return {"id": row["id"], "text": row["text"], "stars": row["stars"] or 0, "created": row["created"], "edited": row["edited"]}

def comment_delete(h, user, q, comment_id):
    user = need(user)
    row = db().execute("SELECT * FROM comments WHERE id = ?", (int(comment_id),)).fetchone()
    if row is None:
        refuse(404, "нет такого комментария")
    if row["user_id"] != user["id"] and not is_admin(user):
        refuse(403, "это не ваш комментарий")
    db().execute("UPDATE comments SET deleted = 1 WHERE id = ?", (row["id"],))
    # the stars went with the review
    db().execute("DELETE FROM ratings WHERE app_id = ? AND user_id = ?", (row["app_id"], row["user_id"]))
    db().commit()
    return 200, {}

def judge_app(h, user, q, app_id):
    need_admin(user)
    said = h.body()
    action = said.get("action")
    states = {"approve": "approved", "reject": "rejected", "hide": "hidden"}
    link = db()
    if action in states:
        row = link.execute('SELECT * FROM apps WHERE id=?',(int(app_id),)).fetchone()
        if row is None: refuse(404,'Application not found')
        if action == 'approve' and not link.execute("SELECT 1 FROM releases WHERE app_id=? AND status='approved' AND signer!=''",(int(app_id),)).fetchone():
            refuse(409,'Upload a verified APK before publishing')
        link.execute("UPDATE apps SET status = ?, note = ?, updated = ? WHERE id = ?",
                     (states[action], text(said.get("note"), 500, "причина"), now(), int(app_id)))
    elif action in ("official", "unofficial"):
        link.execute("UPDATE apps SET official = ? WHERE id = ?", (int(action == "official"), int(app_id)))
    else:
        refuse(400, "непонятное действие")
    link.commit()
    return 200, {}

def admin_apps(h, user, q):
    need_admin(user)
    status = q.get("status", "all")
    term = "%" + text(q.get("q", ""), 60, "поиск") + "%"
    where, args = "(name LIKE ? OR package LIKE ?)", [term, term]
    if status in ("pending", "approved", "rejected", "hidden"):
        where += " AND status = ?"
        args.append(status)
    rows = db().execute("SELECT * FROM apps WHERE %s ORDER BY updated DESC LIMIT 200" % where, args).fetchall()
    return 200, {"apps": [fix_icon(app_card(r), r) for r in rows]}

def health(h, user, q):
    return 200, {"ok": True}

ORIGIN = 'https://store.markol.fun'
AUTH = os.getenv('MARKAUTH_BASE_URL', 'https://auth.markol.fun').rstrip('/')
CLIENT = os.getenv('MARKAUTH_CLIENT_ID', '')
SECRET = os.getenv('MARKAUTH_CLIENT_SECRET', '')
CALLBACK = os.getenv('MARKAUTH_CALLBACK', ORIGIN + '/auth/callback')
SESSION_KEY = os.getenv('APP_SESSION_KEY', '')
CONTRACT = os.getenv('MARKAUTH_CONTRACT_FILE', '')
ALLOWLIST = os.getenv('ADMIN_ALLOWLIST_FILE', '')


def read_config(path, fallback):
    if not path:
        return fallback
    with open(path, encoding='utf-8') as f:
        return json.load(f)


def identity_of(info, expected_provider):
    # This adapter must be configured from the gateway's verified documentation.
    # No guessed field, email matching or browser-supplied identity is accepted.
    c = read_config(CONTRACT, {})
    if c.get('verified_contract') is not True:
        refuse(503, 'Markol Auth: identity contract is not configured')
    if c.get('project_user_id') is not True:
        refuse(503, 'Confirm project-scoped user_id first')
    subject = info.get('user_id') if isinstance(info, dict) else None
    if type(subject) not in (int, str) or not str(subject).strip() or len(str(subject)) > 200:
        refuse(403, 'Missing project user_id')
    return 'markol:' + CLIENT + ':' + str(subject)



def is_admin(user):
    return user is not None and not user['banned'] and user['identity'] is not None and user['identity'] in read_config(ALLOWLIST, [])


def is_owner(user):
    return is_admin(user)


def user_card(row):
    if row is None:
        return None
    return dict(nick=row['nick'], display=row['display'] or row['nick'], avatar=file_url(row['avatar']))


def me_view(row):
    return user_card(row) | dict(bio=row['bio'], admin=is_admin(row), nick_set=bool(row['nick_set']))


def cookie(h, name, value, age):
    h.extra_headers.append(('Set-Cookie', f'{name}={value}; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age={age}'))


def cookies(h):
    c = SimpleCookie()
    try:
        c.load(h.headers.get('Cookie', ''))
    except Exception:
        return {}
    return {k: v.value for k, v in c.items()}


def token_hash(token):
    return hmac.new(SESSION_KEY.encode(), token.encode(), hashlib.sha256).hexdigest()


def current_session(h):
    tok = cookies(h).get('__Host-kuiz', '')
    h.session_hash = token_hash(tok)
    row = db().execute('SELECT * FROM sessions WHERE token_hash=? AND created>?', (h.session_hash, now()-604800)).fetchone()
    if row is None:
        return None, None
    user = db().execute('SELECT * FROM users WHERE id=? AND banned=0', (row['user_id'],)).fetchone()
    return user, row


def redirect(h, url):
    h.extra_headers.append(('Location', url))
    return 302, {}


def auth_json(path, token=None, data=None):
    if not AUTH.startswith('https://'):
        refuse(503, 'HTTPS required for authentication')
    headers = {'Accept': 'application/json'}
    if token:
        headers['Authorization'] = 'Bearer ' + token
    body = urllib.parse.urlencode(data).encode() if data is not None else None
    req = urllib.request.Request(AUTH+path, data=body, headers=headers)
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    try:
        with urllib.request.build_opener(NoRedirect).open(req, timeout=15) as r:
            raw = r.read(65537)
            if len(raw) > 65536:
                refuse(502, 'Authentication response too large')
            return json.loads(raw) if raw else {}
    except (urllib.error.URLError, ValueError):
        refuse(502, 'Markol Auth unavailable')


def login(h, provider, mobile=None):
    if not CLIENT or not SECRET or len(SESSION_KEY) < 32 or CALLBACK != ORIGIN+'/auth/callback':
        refuse(503, 'Configure Markol Auth and server session key')
    if not all(read_config(CONTRACT, {}).get(k) is True for k in ('verified_contract','project_user_id')):
        refuse(503, 'Markol Auth identity contract is not configured')
    if limited('login:'+h.who(), 20, 600):
        refuse(429, 'Try later')
    state, verifier, browser = (secrets.token_urlsafe(32) for _ in range(3))
    db().execute('DELETE FROM oauth_attempts WHERE created<?', (now()-300,))
    db().execute('INSERT INTO oauth_attempts VALUES(?,?,?,?,?)', (state, token_hash(browser), verifier, provider, now()))
    if mobile is not None:
        challenge, client_state = mobile
        if not all(re.fullmatch('[a-zA-Z0-9_-]{43}', v) for v in mobile):
            refuse(400, 'Invalid Android challenge or state')
        db().execute('DELETE FROM mobile_attempt WHERE created<?',(now()-300,))
        db().execute('INSERT INTO mobile_attempt VALUES(?,?,?,?)',(state,challenge,client_state,now()))
    db().commit()
    cookie(h, '__Host-kuiz_oauth', browser, 300)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b'=').decode()
    return redirect(h, AUTH+'/oauth/'+provider+'/v1/'+urllib.parse.quote(CLIENT, safe='')+'?'+urllib.parse.urlencode(dict(state=state, redirect_uri=CALLBACK, code_challenge=challenge, code_challenge_method='S256')))


def callback(h, q):
    state = q.get('state', '')
    browser = token_hash(cookies(h).get('__Host-kuiz_oauth', ''))
    with db():
        row = db().execute('DELETE FROM oauth_attempts WHERE state=? AND browser=? AND created>? RETURNING *', (state, browser, now()-300)).fetchone()
    cookie(h, '__Host-kuiz_oauth', '', 0)
    if row is None:
        refuse(400, 'Expired, invalid or reused OAuth state')
    if q.get('error'):
        return redirect(h, '/account?cancelled=1')
    if not q.get('code'):
        refuse(400, 'Missing authorization code')
    result = auth_json('/oauth/token', data=dict(grant_type='authorization_code', client_id=CLIENT, client_secret=SECRET, redirect_uri=CALLBACK, code=q['code'], code_verifier=row['verifier']))
    access = result.get('access_token')
    if not isinstance(access, str) or not access:
        refuse(502, 'Missing access token')
    try:
        info = auth_json('/oauth/userinfo', token=access)
        identity = identity_of(info, row['provider'])
    finally:
        try:
            auth_json('/oauth/revoke', token=access, data={})
        except Refusal:
            pass
    user = db().execute('SELECT * FROM users WHERE identity=?', (identity,)).fetchone()
    if user is None:
        nick = free_nick('user')
        db().execute('INSERT INTO users(nick,display,created,identity) VALUES(?,?,?,?)', (nick, nick, now(), identity))
        db().commit()
        user = db().execute('SELECT * FROM users WHERE identity=?', (identity,)).fetchone()
    if user['banned']:
        refuse(403, 'Account blocked')
    with db():
        mobile = db().execute('DELETE FROM mobile_attempt WHERE state=? RETURNING *',(state,)).fetchone()
        if mobile:
            code = secrets.token_urlsafe(32)
            db().execute('DELETE FROM mobile_codes WHERE expires<?',(now(),))
            db().execute('INSERT INTO mobile_codes VALUES(?,?,?,?)',(token_hash(code),mobile['challenge'],user['id'],now()+60))
            return redirect(h, 'kuizstore://login/complete?' + urllib.parse.urlencode(dict(code=code,state=mobile['client_state'])))
    old = cookies(h).get('__Host-kuiz', '')
    db().execute('DELETE FROM sessions WHERE token_hash=?', (token_hash(old),))
    db().commit()
    cookie(h, '__Host-kuiz', new_session(user['id']), 604800)
    return redirect(h, '/account')


def logout(h, user, q):
    db().execute('DELETE FROM sessions WHERE token_hash=?', (h.session_hash,))
    db().commit()
    cookie(h, '__Host-kuiz', '', 0)
    return 200, {}


def profile(h, user, q, nick):
    row = db().execute('SELECT * FROM users WHERE nick=?', (nick,)).fetchone()
    if row is None:
        refuse(404, 'User not found')
    return 200, user_card(row) | dict(bio=row['bio'], created=row['created'], apps=[app_card(a) for a in db().execute("SELECT * FROM apps WHERE owner_id=? AND status='approved'", (row['id'],))])


def apps(h, user, q):
    term = '%'+text(q.get('q'), 60, 'search')+'%'
    rows = db().execute("SELECT * FROM apps WHERE status='approved' AND (name LIKE ? OR summary LIKE ? OR package LIKE ?) ORDER BY updated DESC LIMIT 200", (term, term, term))
    return 200, {'apps': [app_card(r) for r in rows]}


def icon_url(stored):
    return file_url(stored) if stored and not stored.startswith('builtin:') else ''


def app_row(app_id, user=None, edit=False, unverified=False):
    if edit:
        need_admin(user)
    row = db().execute('SELECT * FROM apps WHERE id=?', (app_id,)).fetchone()
    if row is None or (row['status'] != 'approved' and not is_admin(user)):
        refuse(404, 'Application not found')
    return row


def release_view(row):
    return dict(id=row['id'], version=row['version'], notes=row['notes'], beta=bool(row['beta']), kind='apk', created=row['created'], status=row['status'], note=row['note'], notes_tr=tr_of(row['notes_tr']), apk=dict(url='/api/download/'+str(row['id']) if row['file'] else '', sha256=row['sha256'], size=row['size']), versionCode=row['version_code'], minSdk=row['min_sdk'])


def visible_releases(app, user, all_of_them=False):
    return [release_view(r) for r in db().execute('SELECT * FROM releases WHERE app_id=? ORDER BY version_code DESC,id DESC', (app['id'],)) if r['status']=='approved' or (all_of_them and is_admin(user))]


def submit(h, user, q):
    need_admin(user)
    s = h.body()
    package, name = text(s.get('package'),120,'package'), text(s.get('name'),40,'name')
    if not name or not re.fullmatch(r'[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z0-9_]+)+',package):
        refuse(400,'Valid package and name required')
    slug = secrets.token_hex(8)
    db().execute("INSERT INTO apps(slug,package,name,summary,description,git,license,owner_id,status,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(slug,package,name,text(s.get('summary'),140,'summary'),text(s.get('description'),6000,'description'),safe_url(s.get('git','')),text(s.get('license'),60,'license'),user['id'],'hidden',now(),now()))
    db().commit()
    return 200, {'id':db().execute('SELECT id FROM apps WHERE slug=?',(slug,)).fetchone()[0]}


def safe_url(value):
    value=text(value,300,'url')
    if value and not value.startswith('https://'):
        refuse(400,'HTTPS URL required')
    return value


def release_file(h, user, q, release_id):
    need_admin(user)
    from apk import inspect_apk
    rel=db().execute('SELECT * FROM releases WHERE id=?',(release_id,)).fetchone()
    if rel is None:
        refuse(404,'Release not found')
    a=app_row(rel['app_id'],user,edit=True)
    if rel['status']=='approved':
        refuse(409,'Published release is immutable')
    name,digest,size=save_upload(h.rfile,int(h.headers.get('Content-Length') or 0),'apk',APK_MOST)
    try:
        meta=inspect_apk(os.path.join(FILES,name))
        if meta['package'] != a['package'] or meta['version'] != rel['version']:
            refuse(400,'APK package/version mismatch')
        db().execute('BEGIN IMMEDIATE')
        fresh=db().execute('SELECT status FROM releases WHERE id=?',(rel['id'],)).fetchone()
        if fresh['status']=='approved': refuse(409,'Release already published')
        previous=db().execute("SELECT * FROM releases WHERE app_id=? AND status='approved' ORDER BY version_code DESC LIMIT 1",(a['id'],)).fetchone()
        if previous and (previous['signer']!=meta['signer'] or previous['version_code']>=meta['version_code']):
            refuse(409,'Signature mismatch or non-increasing versionCode')
        db().execute("UPDATE releases SET file=?,sha256=?,size=?,signer=?,version_code=?,min_sdk=?,status='approved' WHERE id=?",(name,digest,size,meta['signer'],meta['version_code'],meta['min_sdk'],rel['id']))
        db().execute('UPDATE apps SET updated=? WHERE id=?',(now(),a['id']))
        db().commit()
    except Exception:
        forget_file(name)
        raise
    forget_file(rel['file'])
    return 200,dict(sha256=digest,size=size,status='approved',metadata=meta)


def download(h,user,q,release_id):
    r=db().execute("SELECT r.* FROM releases r JOIN apps a ON a.id=r.app_id WHERE r.id=? AND r.status='approved' AND a.status='approved'",(release_id,)).fetchone()
    if r is None or not r['file']:
        refuse(404,'Release unavailable')
    db().execute('INSERT INTO downloads(release_id,count) VALUES(?,1) ON CONFLICT(release_id) DO UPDATE SET count=count+1',(release_id,))
    db().commit()
    h.extra_headers.append(('X-Accel-Redirect','/private-apk/'+Path(r['file']).name))
    h.extra_headers.append(('Content-Disposition','attachment; filename="'+Path(r['file']).name+'"'))
    return 200, {}


def admin_users(h,user,q):
    need_admin(user)
    return 200,{'users':[user_card(r)|dict(banned=bool(r['banned']),admin=is_admin(r),created=r['created']) for r in db().execute('SELECT * FROM users ORDER BY created DESC LIMIT 200')]}


def ban(h,user,q):
    need_admin(user)
    s=h.body()
    target=db().execute('SELECT * FROM users WHERE nick=?',(str(s.get('nick','')),)).fetchone()
    if target is None: refuse(404,'User not found')
    if is_admin(target): refuse(403,'Cannot block owner')
    db().execute('UPDATE users SET banned=? WHERE id=?',(int(s.get('action')!='unban'),target['id']))
    for table in ('sessions','mobile_sessions','mobile_codes'):
        db().execute('DELETE FROM '+table+' WHERE user_id=?',(target['id'],))
    db().commit()
    return 200,{}


def stats(h,user,q):
    need_admin(user)
    return 200,{'downloads':[dict(r) for r in db().execute('SELECT * FROM downloads')], 'audit':[dict(r) for r in db().execute('SELECT * FROM audit ORDER BY id DESC LIMIT 100')]}


def self_update(h,user,q):
    r=db().execute("SELECT r.* FROM releases r JOIN apps a ON a.id=r.app_id WHERE a.package='fun.markol.kuizstore' AND a.status='approved' AND r.status='approved' ORDER BY r.version_code DESC LIMIT 1").fetchone()
    if r is None: return 200,{}
    return 200, release_view(r)|dict(versionCode=r['version_code'],versionName=r['version'],url='/api/download/'+str(r['id']),sha256=r['sha256'],size=r['size'])

ROUTES=[
('GET',r'/health',health),('GET',r'/self',self_update),('POST',r'/auth/logout',logout),
('GET',r'/me',me),('PATCH',r'/me',me_edit),('POST',r'/me/avatar',me_avatar),
('GET',r'/users',people),('GET',r'/users/([a-zA-Z0-9_.]+)',profile),
('GET',r'/apps',apps),('POST',r'/apps',submit),('GET',r'/apps/(\d+)',app),('PATCH',r'/apps/(\d+)',app_edit),
('POST',r'/apps/(\d+)/(icon|cover)',app_picture),('POST',r'/apps/(\d+)/releases',release_new),('POST',r'/releases/(\d+)/file',release_file),
('GET',r'/apps/(\d+)/comments',comments),('POST',r'/apps/(\d+)/comments',comment_new),('DELETE',r'/comments/(\d+)',comment_delete),
('POST',r'/comments/(\d+)/vote',comment_vote),('POST',r'/comments/(\d+)/pin',comment_pin),('POST',r'/comments/(\d+)/reply',comment_reply),
('GET',r'/admin/users',admin_users),('GET',r'/admin/apps',admin_apps),('GET',r'/admin/stats',stats),('POST',r'/admin/ban',ban),('POST',r'/admin/apps/(\d+)',judge_app),
('GET',r'/download/(\d+)',download)]
ADMIN_HANDLERS={submit,app_edit,app_picture,release_new,release_file,comment_pin,comment_reply,admin_users,admin_apps,stats,ban,judge_app}


def dispatch(h,method,path,q):
    if path == '/api/android/exchange' and method == 'POST':
        body = h.body()
        verifier, code = body.get('verifier'), body.get('code')
        if not all(isinstance(v,str) and re.fullmatch('[a-zA-Z0-9_-]{43}',v) for v in (verifier,code)):
            refuse(400,'Invalid exchange')
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b'=').decode()
        with db():
            grant = db().execute('DELETE FROM mobile_codes WHERE digest=? AND challenge=? AND expires>? RETURNING user_id',(token_hash(code),challenge,now())).fetchone()
            if not grant: refuse(403,'Invalid or expired code')
            token = secrets.token_urlsafe(32)
            db().execute('DELETE FROM mobile_sessions WHERE expires<=?',(now(),))
            db().execute('INSERT INTO mobile_sessions VALUES(?,?,?)',(token_hash(token),grant[0],now()+604800))
        h.extra_headers.append(('Cache-Control','no-store'))
        return 200, dict(token=token)
    if path.startswith('/api/android/login/') and method=='GET':
        provider = path.rsplit('/',1)[1]
        if provider not in ('google','telegram'): refuse(404,'Unknown provider')
        return login(h,provider,(q.get('challenge',''),q.get('state','')))
    user,session=current_session(h)
    mobile_token = h.headers.get('Authorization','').removeprefix('Bearer ')
    mobile = None
    if mobile_token:
        mobile = db().execute('SELECT u.* FROM mobile_sessions s JOIN users u ON s.user_id=u.id WHERE s.digest=? AND s.expires>? AND u.banned=0',(token_hash(mobile_token),now())).fetchone()
        if not mobile: refuse(401,'Session expired')
        user = dict(mobile) | {'identity': None}
        if method=='POST' and path=='/api/auth/logout':
            with db(): db().execute('DELETE FROM mobile_sessions WHERE digest=?',(token_hash(mobile_token),))
            return 200, {}
        if not path.startswith('/api/') or (method!='GET' and not re.fullmatch(r'/api/(apps/\d+/comments|comments/\d+(/vote)?|me)',path)):
            refuse(403,'Web access required')
    if path.startswith('/login/') and method=='GET':
        provider=path.split('/')[-1]
        if provider not in ('google','telegram'): refuse(404,'Unknown provider')
        return login(h,provider)
    if path=='/auth/callback' and method=='GET': return callback(h,q)
    if path=='/admin' and method=='GET':
        need_admin(user)
        return 200,{'__html__':Path(HERE,'../site/web/index.html').read_text()}
    if not path.startswith('/api/'): refuse(404,'Not found')
    path=path[4:]
    if path=='/session' and method=='GET':
        return 200,dict(me=me_view(user) if user else None,csrf=session['csrf'] if session and not mobile else '')
    for verb,pattern,handler in ROUTES:
        m=re.fullmatch(pattern,path)
        if verb!=method or not m: continue
        if mobile and handler in ADMIN_HANDLERS: refuse(403,'Web access required')
        if handler in ADMIN_HANDLERS: need_admin(user)
        if method!='GET':
            need(user)
            if not mobile and (h.headers.get('Origin')!=ORIGIN or not session or not hmac.compare_digest(h.headers.get('X-CSRF-Token',''),session['csrf'])): refuse(403,'CSRF rejected')
            if limited('write:'+str(user['id']),120,600): refuse(429,'Try later')
        result=handler(h,user,q,*m.groups())
        if method!='GET' and is_admin(user):
            db().execute('INSERT INTO audit(user_id,action,created) VALUES(?,?,?)',(user['id'],method+' '+path,now()))
            db().commit()
        return result
    refuse(404,'Not found')


def screenshot_upload(h,user,q,app_id):
    need_admin(user); app_row(int(app_id),user,edit=True)
    if db().execute('SELECT COUNT(*) FROM screenshots WHERE app_id=?',(app_id,)).fetchone()[0]>=12: refuse(400,'At most 12 screenshots')
    name,_,_=save_upload(h.rfile,int(h.headers.get('Content-Length') or 0),'image',IMAGE_MOST)
    db().execute('INSERT INTO screenshots(app_id,file) VALUES(?,?)',(app_id,name)); db().commit()
    return 200,{'url':file_url(name)}

def screenshot_delete(h,user,q,shot_id):
    need_admin(user)
    r=db().execute('SELECT * FROM screenshots WHERE id=?',(shot_id,)).fetchone()
    if r:
        db().execute('DELETE FROM screenshots WHERE id=?',(shot_id,));db().commit();forget_file(r['file'])
    return 200,{}

def app_delete(h,user,q,app_id):
    need_admin(user);app_row(int(app_id),user,edit=True)
    db().execute("UPDATE apps SET status='deleted',updated=? WHERE id=?",(now(),app_id));db().commit()
    return 200,{}

ROUTES.extend([('POST',r'/apps/(\d+)/screenshots',screenshot_upload),('DELETE',r'/screenshots/(\d+)',screenshot_delete),('DELETE',r'/apps/(\d+)',app_delete)])
ADMIN_HANDLERS.update({screenshot_upload,screenshot_delete,app_delete})

def initialize():
    os.makedirs(FILES,exist_ok=True)
    if db().execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='users'").fetchone():
        cols={r[1] for r in db().execute('PRAGMA table_info(users)')}
        if 'identity' not in cols:
            raise RuntimeError('Legacy database: run migrate.py explicitly; backup is mandatory')
    db().executescript(Path(HERE,'schema.sql').read_text())
    os.chmod(DB,0o600)


def main():
    initialize()
    server=ThreadingHTTPServer(('127.0.0.1',int(os.getenv('PORT','8092'))),Handler)
    server.daemon_threads=True
    print('KuizStore listening on loopback',flush=True)
    server.serve_forever()

if __name__=='__main__':
    sys.modules['store'] = sys.modules[__name__]
    main()
