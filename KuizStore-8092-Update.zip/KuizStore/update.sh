#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
cd "$(dirname "$(readlink -f "$0")")"
[[ $EUID == 0 ]] || { echo 'Запустите sudo bash update.sh'; exit 1; }
exec 9>/run/lock/kuizstore-update.lock
flock -n 9 || { echo 'Обновление уже выполняется'; exit 1; }
app=/opt/kuizstore
envfile=/etc/kuizstore/kuizstore.env
site=/etc/nginx/sites-available/kuizstore
[[ -f $envfile && -f $site && -d $app/server && -x $app/.venv/bin/python ]] || { echo 'Установка из setup.sh не найдена'; exit 1; }
[[ "$(readlink -f /etc/nginx/sites-enabled/kuizstore)" == "$site" ]] || { echo 'Проверьте активный конфиг KuizStore'; exit 1; }
grep -Eq 'server_name[[:space:]]+store\.markol\.fun;' "$site"
listener=$(ss -H -ltnp 'sport = :8092')
pid=$(systemctl show kuizstore.service -p MainPID --value)
if [[ -n $listener && ( $pid == 0 || $listener != *"pid=$pid,"* ) ]]; then
    echo '8092 занят другим процессом'; exit 1
fi
if ! command -v aapt >/dev/null || ! command -v apksigner >/dev/null; then
    apt-get update
    DEBIAN_FRONTEND=noninteractive apt-get install -y aapt apksigner
fi
backup=$(mktemp -d /var/backups/kuizstore-update.XXXXXXXX)
cp -p "$envfile" "$backup/env"
cp -p "$site" "$backup/nginx"
cp -p /etc/systemd/system/kuizstore.service "$backup/unit"
# Save only deployed source, never roll back mutable catalog or uploaded files.
files=()
while IFS= read -r -d '' f; do files+=("$f"); done < <(find server site -type f ! -path '*/__pycache__/*' -print0)
mkdir "$backup/original"
for f in "${files[@]}"; do
    if [[ -f $app/$f ]]; then (cd "$app" && cp --parents -p "$f" "$backup/original/"); fi
done
cp -p "$envfile" "$backup/new-env"
cp -p "$site" "$backup/new-nginx"
python3 - "$backup/new-env" "$backup/new-nginx" <<'PY'
from pathlib import Path
import sys,re,getpass
env,site=map(Path,sys.argv[1:])
text=env.read_text()
def get(name):
    values=re.findall(r'^'+name+r'=(.*)$',text,re.M)
    if len(values)!=1: sys.exit('Проверьте переменную '+name)
    return values[0]
def set_value(name,value):
    global text
    text=re.sub(r'^'+name+r'=.*$',lambda _:name+'='+value,text,flags=re.M)
old=get('PORT')
if old not in ('8091','8092'): sys.exit('Неожиданный исходный порт '+old)
client='c85e0078fbacc59521344b568a4929a3'
if get('MARKAUTH_CLIENT_ID')!=client or not get('MARKAUTH_CLIENT_SECRET'):
    secret=getpass.getpass('Client Secret проекта KuizStore (скрытый ввод): ')
    if not secret or any(c.isspace() or c in chr(34)+chr(39)+chr(92)+'#' for c in secret):sys.exit('Недопустимый формат секрета')
    set_value('MARKAUTH_CLIENT_SECRET',secret)
set_value('MARKAUTH_CLIENT_ID',client)
set_value('PORT','8092')
conf=site.read_text()
if not re.search(r'proxy_pass\s+http://127\.0\.0\.1:809[12]\s*;',conf):sys.exit('Не найден ожидаемый proxy_pass')
site.write_text(re.sub(r'(proxy_pass\s+http://127\.0\.0\.1:)8091(?=\s*;)',r'\g<1>8092',conf))
env.write_text(text)
PY
active=0
if systemctl is-active --quiet kuizstore; then active=1; fi
rollback() {
    rc=$?
    trap - ERR INT TERM
    set +e
    systemctl stop kuizstore
    for f in "${files[@]}"; do
        if [[ -f $backup/original/$f ]]; then cp -p "$backup/original/$f" "$app/$f"; else rm -f "$app/$f"; fi
    done
    cp -p "$backup/env" "$envfile"
    cp -p "$backup/nginx" "$site"
    cp -p "$backup/unit" /etc/systemd/system/kuizstore.service
    systemctl daemon-reload
    if ((active)); then systemctl start kuizstore; fi
    nginx -t && systemctl reload nginx
    echo "Обновление прервано. Резервная копия: $backup"
    exit "${rc:-1}"
}
trap rollback ERR
trap 'false' INT TERM
systemctl stop kuizstore
for f in "${files[@]}"; do install -D -m644 "$f" "$app/$f"; done
chown root:kuizstore /etc/kuizstore
chmod 750 /etc/kuizstore
chmod -R a+rX "$app/.venv"
install -m640 -o root -g kuizstore "$backup/new-env" "$envfile"
install -m644 deploy/kuizstore.service /etc/systemd/system/kuizstore.service
systemctl daemon-reload
systemctl start kuizstore
healthy=0
for _ in {1..20}; do
    if curl -fsS --max-time 2 http://127.0.0.1:8092/api/health 2>/dev/null | python3 -c 'import sys,json; assert json.load(sys.stdin)["ok"] is True' 2>/dev/null; then healthy=1; break; fi
    sleep 1
done
((healthy)) || { echo 'Сервис не прошёл проверку'; false; }
status=$(curl -sS --max-time 3 -o /dev/null -w '%{http_code}' -H 'Content-Type: application/json' -d '{}' http://127.0.0.1:8092/api/android/exchange)
[[ $status == 400 ]]
install -m644 "$backup/new-nginx" "$site"
nginx -t
systemctl reload nginx
trap - ERR INT TERM
echo "KuizStore обновлён на 127.0.0.1:8092. Резервная копия: $backup"
