"""Run while the service is stopped; include DB + uploads in one protected archive."""
import os,sqlite3,tarfile,tempfile,datetime
from pathlib import Path
root=Path(os.environ.get('KUIZ_FILES','/var/lib/kuizstore/files'))
db=Path(os.environ.get('KUIZ_DB','/var/lib/kuizstore/store.db'))
output=Path('kuizstore-backup-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'.tar.gz')
with tempfile.TemporaryDirectory() as t:
    snap=Path(t)/'store.db'
    with sqlite3.connect(db) as source,sqlite3.connect(snap) as target: source.backup(target)
    with tarfile.open(output,'w:gz') as archive:
        archive.add(snap,arcname='store.db')
        if root.exists(): archive.add(root,arcname='files')
os.chmod(output,0o600)
print(output.resolve())
