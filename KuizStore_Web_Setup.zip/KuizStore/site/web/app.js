/*
 * KuizStore on the web: the same store as the app, to look through, with
 * links that open the app when it is on the phone.
 *
 * One page; the address says what is shown: / the front page, /app/12 an
 * app, /u/nick a person, /search, /get the store itself. A page of the app
 * and a page here have the same address, so a link to either is a link to both.
 */
(function () {
  "use strict";

  const API = "/api";
  // tried out under /new/ before it takes the place of the old site
  const BASE = "";
  const ANDROID = /Android/i.test(navigator.userAgent);
  // the language and the theme: the person's choice, or the device's
  const chosen = (k) => { try { return localStorage.getItem(k) || ""; } catch (e) { return ""; } };
  const LANG = (() => {
    const own = chosen("ks_lang");
    if (["ru", "uk", "en", "kk"].includes(own)) return own;
    const l = (navigator.language || "en").slice(0, 2).toLowerCase();
    if(l === "kk") return "kk";
    return l === "uk" ? "uk" : ["ru", "be", "kk"].includes(l) ? "ru" : "en";
  })();
  const theme = chosen("ks_theme");
  if (theme === "light" || theme === "dark") document.documentElement.dataset.theme = theme;
  const KK={'Приложения, отзывы и обновления':'Қолданбалар, пікірлер және жаңартулар','Найти приложение':'Қолданбаны табу','Пока пусто':'Әзірге бос','Скачать':'Жүктеп алу','Поиск':'Іздеу','Настройки':'Баптаулар','Язык':'Тіл','Тема':'Тақырып','Сохранить':'Сақтау','Выйти':'Шығу','Имя':'Аты','О себе':'Өзім туралы','Все приложения':'Барлық қолданбалар','Отзывы':'Пікірлер','Описание':'Сипаттама'};
  const t = (ru, uk, en) => (LANG === 'kk' ? KK[ru] || ru : LANG === 'ru' ? ru : LANG === 'uk' ? uk : en);
  const pick = (map, base) => (map && (map[LANG] || "")) || base || (map && (map.en || Object.values(map)[0])) || "";

  const view = document.getElementById("view");
  const bar = document.querySelector(".bar-wrap");

  // ------------------------------------------------------------------ little helpers

  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const link = (path) => BASE + path;
  const svg = (d, cls) => `<svg viewBox="0 0 24 24" class="${cls || ""}" aria-hidden="true"><path d="${d}"/></svg>`;
  // Google's "G", as its sign-in buttons must show it
  const GOOGLE_G = `<svg class="g" viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>`;
  const ICON = {
    search: "M15.5 14h-.79l-.28-.27A6.47 6.47 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z",
    back: "M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z",
    verified: "M23 12l-2.44-2.78.34-3.68-3.61-.82-1.89-3.18L12 3 8.6 1.54 6.71 4.72l-3.61.81.34 3.68L1 12l2.44 2.78-.34 3.69 3.61.82 1.89 3.18L12 21l3.4 1.46 1.89-3.18 3.61-.82-.34-3.68L23 12zm-12.91 4.72l-3.8-3.81 1.48-1.48 2.32 2.33 5.85-5.87 1.48 1.48-7.33 7.35z",
    download: "M5 20h14v-2H5v2zM19 9h-4V3H9v6H5l7 7 7-7z",
    open: "M19 19H5V5h7V3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z",
    code: "M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z",
    send: "M2.01 21L23 12 2.01 3 2 10l15 2-15 2z",
    note: "M12 3v10.55A4 4 0 1 0 14 17V7h4V3h-6z",
    play: "M8 5v14l11-7z",
    link: "M3.9 12c0-1.71 1.39-3.1 3.1-3.1h4V7H7a5 5 0 0 0 0 10h4v-1.9H7c-1.71 0-3.1-1.39-3.1-3.1zM8 13h8v-2H8v2zm9-6h-4v1.9h4c1.71 0 3.1 1.39 3.1 3.1s-1.39 3.1-3.1 3.1h-4V17h4a5 5 0 0 0 0-10z",
    info: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z",
    up: "M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z",
    down: "M15 3H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 23l6.59-6.59c.36-.36.58-.86.58-1.41V5c0-1.1-.9-2-2-2zm4 0v12h4V3h-4z",
    pin: "M16 9V4h1c.55 0 1-.45 1-1s-.45-1-1-1H7c-.55 0-1 .45-1 1s.45 1 1 1h1v5c0 1.66-1.34 3-3 3v2h5.97v7l1 1 1-1v-7H19v-2c-1.66 0-3-1.34-3-3z",
    warn: "M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z",
    mail: "M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z",
    person: "M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z",
    camera: "M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4zM9 2L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9z",
    add: "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z",
    copy: "M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z",
  };

  // ------------------------------------------------------------------ the account

  const kept = {
    get: (k) => { try { return localStorage.getItem(k) || ""; } catch (e) { return ""; } },
    set: (k, v) => { try { v ? localStorage.setItem(k, v) : localStorage.removeItem(k); } catch (e) { /* private window */ } },
  };
  let csrf = "";
  let me = null;

  /** The store's server: GET, or a body sent as JSON, or a file as it is. */
  async function api(path, method, body) {
    const headers = { Accept: "application/json" };
    if (csrf) headers["X-CSRF-Token"] = csrf;
    let payload;
    if (body !== undefined) { payload = JSON.stringify(body); headers["Content-Type"] = "application/json"; }
    const answer = await fetch((path.startsWith("/api/") ? "" : API) + path,
      { method: method || (body !== undefined ? "POST" : "GET"), headers, body: payload });
    const said = await answer.json().catch(() => ({}));
    if (answer.status === 401) { me=null; paintBar(); }
    if (!answer.ok) throw new Error(said.error || t("Сервер не ответил", "Сервер не відповів", "The server did not answer"));
    return said;
  }

  /** A file to the server, saying how far it has got. */
  function upload(path, file, progress) {
    return new Promise((done, fail) => {
      const x = new XMLHttpRequest();
      x.open("POST", API + path);
      x.setRequestHeader("X-CSRF-Token", csrf);
      x.setRequestHeader("Content-Type", file.type || "application/octet-stream");
      x.upload.onprogress = (e) => progress && e.lengthComputable && progress(e.loaded / e.total);
      x.onload = () => {
        let said = {};
        try { said = JSON.parse(x.responseText); } catch (e) { /* not json */ }
        x.status < 300 ? done(said) : fail(new Error(said.error || "HTTP " + x.status));
      };
      x.onerror = () => fail(new Error(t("Файл не дошёл до сервера", "Файл не дійшов до сервера", "The file did not reach the server")));
      x.send(file);
    });
  }

  function toast(message) {
    const n = document.createElement("div");
    n.className = "toast";
    n.textContent = message;
    document.body.appendChild(n);
    setTimeout(() => n.classList.add("gone"), 3200);
    setTimeout(() => n.remove(), 3600);
  }
  /** Does it, and says what went wrong if the server refused. */
  const act = (work) => async (...args) => { try { await work(...args); } catch (e) { toast(e.message); } };

  // A local fallback icon for applications without an uploaded icon.
  function iconSrc(icon) { return icon && icon.startsWith('/uploads/img/') ? icon : '/web/img/store.svg'; }
  const appIcon = (icon, size) => `<img class="icon" src="${esc(iconSrc(icon))}" alt="" width="${size}" height="${size}" style="width:${size}px;height:${size}px" loading="lazy">`;

  function avatar(person, size) {
    if (person.avatar) return `<img class="avatar" src="${esc(person.avatar)}" alt="" style="width:${size}px;height:${size}px">`;
    const letter = (person.display || person.nick || "M").slice(0, 1).toUpperCase();
    return `<span class="avatar" style="width:${size}px;height:${size}px;font-size:${Math.round(size * 0.42)}px">${esc(letter)}</span>`;
  }

  const name = (p) => `<b>${esc(p.display || p.nick)}</b>`;

  function stars(value) {
    const shown = Math.abs(value - Math.round(value)) < 0.05 ? String(Math.round(value)) : value.toFixed(1);
    return `<span class="rating"><span class="star">★</span>${shown}</span>`;
  }

  function when(seconds) {
    return new Date(seconds * 1000).toLocaleDateString(LANG === "uk" ? "uk-UA" : LANG === "ru" ? "ru-RU" : "en-GB",
      { day: "numeric", month: "long", year: "numeric" });
  }

  function size(bytes) {
    if (!bytes) return "";
    const mb = bytes / 1048576;
    return mb >= 1 ? mb.toFixed(mb >= 100 ? 0 : 1) + " " + t("МБ", "МБ", "MB") : Math.ceil(bytes / 1024) + " " + t("КБ", "КБ", "KB");
  }

  // ------------------------------------------------------------------ markdown

  function inline(source) {
    const pattern = /`([^`]+)`|\[([^\]]+)\]\((https:\/\/[^\s)]+)\)|(https:\/\/[^\s<>]+)/g;
    const simple = text => esc(text).replace(/\*\*([^*]+)\*\*/g,'<b>$1</b>').replace(/\*([^*]+)\*/g,'<i>$1</i>');
    let result='', at=0, m;
    while((m=pattern.exec(String(source)))) {
      result+=simple(String(source).slice(at,m.index));
      if(m[1]!==undefined) result+='<code>'+esc(m[1])+'</code>';
      else { const url=m[3]||m[4]; result+='<a href="'+esc(url)+'" target="_blank" rel="noopener noreferrer">'+esc(m[2]||url)+'</a>'; }
      at=pattern.lastIndex;
    }
    return result+simple(String(source).slice(at));
  }

  function markdown(source) {
    const lines = String(source || "").replace(/\r\n/g, "\n").split("\n");
    const out = [];
    let list = null, para = [], fenced = null;
    const flush = () => {
      if (para.length) { out.push("<p>" + para.map(inline).join("<br>") + "</p>"); para = []; }
      if (list) { out.push(`<${list.kind}>` + list.items.map((i) => "<li>" + inline(i) + "</li>").join("") + `</${list.kind}>`); list = null; }
    };
    for (const raw of lines) {
      if (raw.trim().startsWith("```")) {
        if (fenced) { out.push("<pre><code>" + esc(fenced.join("\n")) + "</code></pre>"); fenced = null; }
        else { flush(); fenced = []; }
        continue;
      }
      if (fenced) { fenced.push(raw); continue; }
      const line = raw.trimEnd();
      let m;
      if (!line.trim()) { flush(); continue; }
      if ((m = line.match(/^(#{1,6})\s+(.*)$/))) { flush(); out.push(`<h${Math.min(4, m[1].length)}>${inline(m[2])}</h${Math.min(4, m[1].length)}>`); continue; }
      if ((m = line.match(/^>\s?(.*)$/))) { flush(); out.push("<blockquote>" + inline(m[1]) + "</blockquote>"); continue; }
      if (/^(-{3,}|\*{3,}|_{3,})$/.test(line.trim())) { flush(); out.push("<hr>"); continue; }
      if ((m = line.match(/^\s*[-*+]\s+(.*)$/)) || (m = line.match(/^\s*\d+[.)]\s+(.*)$/))) {
        const kind = /^\s*\d/.test(line) ? "ol" : "ul";
        if (para.length) flush();
        if (list && list.kind !== kind) flush();
        if (!list) list = { kind, items: [] };
        list.items.push(m[1]);
        continue;
      }
      if (list) flush();
      para.push(line);
    }
    if (fenced) out.push("<pre><code>" + esc(fenced.join("\n")) + "</code></pre>");
    flush();
    return out.join("");
  }

  // ------------------------------------------------------------------ the store app

  let self = null;
  const selfAsked = api("/self").then((s) => (self = s && s.url ? s : null)).catch(() => null);

  /** An address that opens the store on this page, or this page when the store is not installed. */
  function openButton() { return ""; }

  // ------------------------------------------------------------------ pages

  const pages = {
    async home() {
      document.title='KuizStore';
      view.innerHTML=`<div class="hero"><img src="/web/img/store.svg" alt=""><div class="grow"><h1>KuizStore</h1><p>${t('Приложения, отзывы и обновления','Застосунки, відгуки та оновлення','Apps, reviews and updates')}</p><a class="btn filled" href="/search" data-link>${t('Найти приложение','Знайти застосунок','Find an app')}</a></div></div><div id="apps" class="grid stagger"></div>`;
      const said=await api('/apps');
      view.querySelector('#apps').innerHTML=said.apps.length?said.apps.map(appCard).join(''):`<p class="empty">${t('Пока пусто','Поки порожньо','Nothing here yet')}</p>`;
    },

    async app(id) {
      view.innerHTML = `<div class="loading"></div>`;
      const a = await api("/apps/" + encodeURIComponent(id));
      document.title = a.name + " · KuizStore";
      const summary = pick(a.summary_tr, a.summary);
      const description = pick(a.description_tr, a.description) || summary;
      const releases = (a.releases || []).filter((r) => r.status === "approved" || a.status === "pending");
      const stable = releases.find((r) => !r.beta);
      const latest = stable || releases[0];
      const author = a.author || {};
      const buttons = [];
      if (a.git && /^https:\/\//.test(a.git)) buttons.push({ title: t("Исходный код", "Вихідний код", "Source code"), url: a.git });
      (a.buttons || []).filter(b=>!b.url || /^https:\/\//.test(b.url)).forEach((b) => buttons.push(b));

      const iconFor = (b) => {
        const u = (b.url || "").toLowerCase();
        if (!u) return ICON.info;
        if (u.includes("t.me/") || u.startsWith("tg:")) return ICON.send;
        if (u.includes("tiktok.com")) return ICON.note;
        if (u.includes("youtube.com") || u.includes("youtu.be")) return ICON.play;
        if (/github\.com|git\.|gitlab|codeberg/.test(u)) return ICON.code;
        return ICON.link;
      };

      // the cover beside who the app is on a wide screen, above it on a phone
      let html = `<div class="app-top ${a.cover ? "with-cover" : ""}">`;
      if (a.cover) html += `<img class="cover" src="${esc(a.cover)}" alt="">`;
      html += `<div class="app-main"><div class="app-head">${appIcon(a.icon, 96)}<div>
          <h1>${esc(a.name)}${a.official ? svg(ICON.verified, "verified") : ""}</h1>
          ${author.nick ? `<a class="author" href="${link("/u/" + encodeURIComponent(author.nick))}" data-link>${avatar(author, 24)}${name(author, 18)}</a>`
                        : `<span class="author">${avatar(author, 24)}<b>${esc(author.display || "KuizStore")}</b></span>`}
          <div class="meta">${a.ratings ? stars(a.rating) + `<span class="note">(${a.ratings})</span>` : ""}
            ${latest ? `<span class="pill primary">${esc(latest.version)}</span>` : ""}
            ${a.license ? `<span class="pill">${esc(a.license)}</span>` : ""}</div>
        </div></div>`;
      if (a.status === "pending") {
        html += `<div class="warn">${t("Это приложение ещё никто не проверял. В нём может быть что угодно, вплоть до вирусов.",
          "Цей застосунок ще ніхто не перевіряв. У ньому може бути що завгодно, аж до вірусів.",
          "Nobody has reviewed this app yet. It could contain anything, malware included.")}</div>`;
      }

      if(me?.admin) html+=`<div class="card admin-bar"><a class="btn tonal" href="/edit/${a.id}" data-link>${t('Редактировать','Редагувати','Edit')}</a></div>`;

      // getting it: through the store, or, for an app handed out whole, its apk as well
      html += `<div class="actions">${openButton("/app/" + a.id, ANDROID ? t("Установить в KuizStore", "Встановити в KuizStore", "Install in KuizStore") : "")}`;
      if (latest && latest.kind === "apk" && latest.apk && latest.apk.url) {
        html += `<a class="btn ${ANDROID ? "tonal" : "filled"} big" href="${esc(latest.apk.url)}">${svg(ICON.download)}${t("Скачать апк", "Завантажити апк", "Download apk")} · ${size(latest.apk.size)}</a>`;
      }
      html += `</div>`;
      html += `</div></div>`;

      if(a.screenshots?.length) html+=`<div class="screenshots">${a.screenshots.map(i=>`<a href="${esc(i.url)}" target="_blank" rel="noopener"><img src="${esc(i.url)}" alt="${esc(a.name)}" loading="lazy"></a>`).join('')}</div>`;
      if (description) {
        html += `<div class="card section" id="about" style="cursor:pointer"><h2>${t("Описание", "Опис", "About")}</h2>
          <div class="md fade">${markdown(description)}</div>
          <button class="btn text" style="margin:6px 0 -6px -12px">${t("Читать полностью", "Читати повністю", "Read more")}</button></div>`;
      }
      if (buttons.length) {
        html += `<div class="actions">${buttons.map((b, i) => b.url
          ? `<a class="btn outlined" href="${esc(b.url)}" target="_blank" rel="noopener">${svg(iconFor(b))}${esc(b.title)}</a>`
          : `<button class="btn outlined" data-popup="${i}">${svg(ICON.info)}${esc(b.title)}</button>`).join("")}</div>`;
      }
      if (latest) {
        const notes = pick(latest.notes_tr, latest.notes);
        if (notes) html += `<div class="card section"><h2>${t("Что нового в ", "Що нового в ", "What's new in ")}${esc(latest.version)}</h2><div class="md">${markdown(notes)}</div></div>`;
      }
      if (releases.length > 1) {
        html += `<div class="section"><h2>${t("Все версии", "Усі версії", "All versions")}</h2><div class="rows">${releases.map((r) => `
          <div><div class="grow"><b>${esc(r.version)}</b>${r.beta ? ' <span class="pill tertiary">beta</span>' : ""}
          <div class="note">${when(r.created)}${r.kind === "apk" && r.apk ? " · " + size(r.apk.size) : ""}</div></div>
          ${r.kind === "apk" && r.apk && r.apk.url ? `<a class="btn text" href="${esc(r.apk.url)}">${svg(ICON.download)}</a>` : ""}</div>`).join("")}</div></div>`;
      }
      html += `<div class="section" id="reviews"><h2>${t("Отзывы", "Відгуки", "Reviews")}</h2>
        <div id="my-review"></div>
        <div class="chips"><button class="chip on" data-sort="top">${t("Популярные", "Популярні", "Top")}</button>
        <button class="chip" data-sort="new">${t("Новые", "Нові", "Newest")}</button></div>
        <div id="review-list"><div class="loading"></div></div></div>`;
      view.innerHTML = html;

      view.querySelectorAll("[data-judge]").forEach((b) => (b.onclick = judgeWith("/admin/apps/" + a.id, b.dataset.judge, render)));
      const about = view.querySelector("#about");
      if (about) about.onclick = (e) => { if (!e.target.closest("a")) dialog(a.name, `<div class="md">${markdown(description)}</div>`, true); };
      view.querySelectorAll("[data-popup]").forEach((b) => (b.onclick = () => {
        const one = buttons[+b.dataset.popup];
        dialog(one.title, `<div class="md">${markdown(one.text)}</div>`);
      }));
      let sorting = "top";
      const reviews = async (sort) => {
        sorting = sort;
        view.querySelectorAll("[data-sort]").forEach((c) => c.classList.toggle("on", c.dataset.sort === sort));
        const list = view.querySelector("#review-list");
        try {
          const said = await api(`/apps/${a.id}/comments?sort=${sort}`);
          list.innerHTML = said.comments.length ? said.comments.map(review).join("")
            : `<p class="empty" style="padding:8px 0">${t("Пока никто ничего не написал", "Поки ніхто нічого не написав", "No reviews yet")}</p>`;
        } catch (e) { list.innerHTML = `<p class="empty">${esc(e.message)}</p>`; }
      };
      view.querySelectorAll("[data-sort]").forEach((c) => (c.onclick = () => reviews(c.dataset.sort)));
      reviews("top");

      // the person's own review: stars and words go together, one each
      const paintMine = () => {
        const box = view.querySelector("#my-review");
        const mine = a.my_review;
        if (!me) {
          box.innerHTML = `<div class="card" style="margin-bottom:12px">${t("Войдите, чтобы оценить приложение и написать отзыв",
            "Увійдіть, щоб оцінити застосунок і написати відгук", "Sign in to rate the app and write a review")}
            <div><a class="btn text" style="margin:6px 0 -8px -12px" href="${link("/account")}" data-link>${t("Войти", "Увійти", "Sign in")}</a></div></div>`;
          return;
        }
        box.innerHTML = mine
          ? `<div class="card" style="margin-bottom:12px"><b>${t("Ваш отзыв", "Ваш відгук", "Your review")}</b>
              <div class="star">${"★".repeat(mine.stars)}<span style="color:var(--outline)">${"★".repeat(5 - mine.stars)}</span></div>
              ${mine.text ? `<div class="text" style="white-space:pre-wrap">${esc(mine.text)}</div>` : ""}
              <div style="margin:6px 0 -8px -12px"><button class="btn text" data-write>${t("Изменить", "Змінити", "Edit")}</button>
              <button class="btn text" data-unwrite>${t("Удалить", "Видалити", "Delete")}</button></div></div>`
          : `<div class="card" style="margin-bottom:12px"><b>${t("Оцените приложение", "Оцініть застосунок", "Rate this app")}</b>
              <div class="note">${t("Оценка засчитается вместе с отзывом", "Оцінка зарахується разом із відгуком", "The rating counts once the review is posted")}</div>
              <div class="pick-stars">${[5, 4, 3, 2, 1].map((n) => `<button data-write="${n}" aria-label="${n}">★</button>`).join("")}</div></div>`;
        box.querySelectorAll("[data-write]").forEach((b) => (b.onclick = () => writeReview(a, +b.dataset.write || (mine && mine.stars) || 0, async () => {
          const fresh = await api("/apps/" + a.id);
          a.my_review = fresh.my_review;
          paintMine();
          reviews(sorting);
        })));
        const remove = box.querySelector("[data-unwrite]");
        if (remove) remove.onclick = () => confirmDialog(t("Удалить ваш отзыв?", "Видалити ваш відгук?", "Delete your review?"),
          t("Оценка удалится вместе с ним.", "Оцінка видалиться разом із ним.", "Your rating goes with it."), act(async () => {
            await api("/comments/" + mine.id, "DELETE");
            a.my_review = null;
            paintMine();
            reviews(sorting);
          }));
      };
      paintMine();
      view.querySelector("#review-list").addEventListener("click", act(async (e) => {
        const b = e.target.closest("[data-vote],[data-pin],[data-delete],[data-answer-review]");
        if (!b) return;
        const id = b.closest("[data-review]").dataset.review;
        if (b.dataset.vote !== undefined) {
          if (!me) { toast(t("Сначала войдите", "Спершу увійдіть", "Sign in first")); return; }
          await api(`/comments/${id}/vote`, "POST", { vote: +b.dataset.vote });
        } else if (b.dataset.answerReview !== undefined) {
          const was = b.closest("[data-review]").querySelector(".reply .text");
          const said = await new Promise((answer) => {
            const d = dialog(t("Ответ на отзыв", "Відповідь на відгук", "Reply to the review"), `<textarea class="field" rows="4" maxlength="1000"
              placeholder="${t("Ответ увидят все, под отзывом", "Відповідь побачать усі, під відгуком", "Everyone sees it under the review")}">${esc(was ? was.textContent : "")}</textarea>`,
              false, [t("Отмена", "Скасувати", "Cancel"), t("Ответить", "Відповісти", "Reply")]);
            let given = null;
            d.querySelector("[data-ok]").onclick = () => { given = d.querySelector("textarea").value.trim(); d.close(); };
            d.addEventListener("close", () => answer(given));
          });
          if (said === null) return;
          await api(`/comments/${id}/reply`, "POST", { text: said });
        } else if (b.dataset.pin !== undefined) {
          await api(`/comments/${id}/pin`, "POST", { pinned: b.dataset.pin === "1" });
        } else {
          if (!(await ask(t("Удалить отзыв?", "Видалити відгук?", "Delete the review?")))) return;
          await api("/comments/" + id, "DELETE");
        }
        reviews(sorting);
      }));
    },

    async user(nick) {
      view.innerHTML = `<div class="loading"></div>`;
      const p = await api("/users/" + encodeURIComponent(nick));
      document.title = (p.display || p.nick) + " · KuizStore";
      view.innerHTML = `<div class="profile">${avatar(p, 120)}
          <h1>${esc(p.display || p.nick)} </h1>
          <div class="note">@${esc(p.nick)}</div>
          ${p.bio ? `<p>${esc(p.bio)}</p>` : ""}
          ${p.created ? `<div class="note">${t("С нами с ", "З нами з ", "Joined ")}${when(p.created)}</div>` : ""}
          <div class="actions" style="justify-content:center">
            ${me && me.nick.toLowerCase() === p.nick.toLowerCase() ? `<a class="btn tonal" href="${link("/account")}" data-link>${t("Изменить профиль", "Змінити профіль", "Edit profile")}</a>` : ""}
            ${openButton("/u/" + encodeURIComponent(p.nick), t("Открыть в KuizStore", "Відкрити в KuizStore", "Open in KuizStore")).replace("btn filled big", "btn outlined")}</div>
        </div>
        ${p.apps.length ? `<div class="section"><h2>${t("Приложения", "Застосунки", "Apps")}</h2><div class="grid">${p.apps.map(appCard).join("")}</div></div>` : ""}`;
    },

    async search(query, kind) {
      kind = kind || "all";
      document.title = t("Поиск", "Пошук", "Search") + " · KuizStore";
      view.innerHTML = `
        <div class="search-field">${svg(ICON.search, "")}<input id="q" type="search" autocomplete="off"
          placeholder="${t("Приложение или человек", "Застосунок або людина", "An app or a person")}" value="${esc(query || "")}"></div>
        <div class="chips">${[["all", t("Всё", "Усе", "All")], ["apps", t("Приложения", "Застосунки", "Apps")], ["people", t("Люди", "Люди", "People")]]
          .map(([k, l]) => `<button class="chip ${k === kind ? "on" : ""}" data-kind="${k}">${l}</button>`).join("")}</div>
        <div id="found"></div>`;
      view.querySelector(".search-field svg").setAttribute("style", "width:24px;height:24px;fill:var(--on-surface-variant)");
      const input = view.querySelector("#q");
      const found = view.querySelector("#found");
      let timer = 0, asked = 0;
      const run = async () => {
        const term = input.value.trim();
        history.replaceState(null, "", link("/search") + (term ? "?q=" + encodeURIComponent(term) + (kind !== "all" ? "&k=" + kind : "") : ""));
        if (!term) { found.innerHTML = ""; return; }
        const mine = ++asked;
        found.innerHTML = `<div class="loading"></div>`;
        const [apps, people] = await Promise.all([
          kind !== "people" ? api("/apps?scope=all&q=" + encodeURIComponent(term)).then((s) => s.apps) : [],
          kind !== "apps" ? api("/users?q=" + encodeURIComponent(term)).then((s) => s.users) : [],
        ]).catch(() => [[], []]);
        if (mine !== asked) return;
        let html = "";
        if (people.length) {
          html += `<div class="section">${kind === "all" ? `<h2>${t("Люди", "Люди", "People")}</h2>` : ""}<div class="people">${people.slice(0, kind === "all" ? 5 : 30).map((p) =>
            `<a class="person" href="${link("/u/" + encodeURIComponent(p.nick))}" data-link>${avatar(p, 48)}<div>${name(p, 18)}<div class="note">@${esc(p.nick)}</div></div></a>`).join("")}</div></div>`;
        }
        if (apps.length) html += `<div class="section">${kind === "all" ? `<h2>${t("Приложения", "Застосунки", "Apps")}</h2>` : ""}<div class="grid">${apps.map(appCard).join("")}</div></div>`;
        found.innerHTML = html || `<p class="empty">${t("Ничего не нашлось", "Нічого не знайшлося", "Nothing found")}</p>`;
      };
      input.oninput = () => { clearTimeout(timer); timer = setTimeout(run, 300); };
      view.querySelectorAll("[data-kind]").forEach((c) => (c.onclick = () => {
        kind = c.dataset.kind;
        view.querySelectorAll("[data-kind]").forEach((x) => x.classList.toggle("on", x === c));
        run();
      }));
      input.focus();
      if (query) run();
    },

    async get() {
      document.title='KuizStore';await selfAsked;
      view.innerHTML=`<div class="hero"><img src="/web/img/store.svg" alt=""><div><h1>KuizStore</h1>${self?`<a class="btn filled" href="${esc(self.url)}">${t('Скачать','Завантажити','Download')} ${esc(self.version)}</a>`:`<p>${t('APK KuizStore пока не опубликован. Каталог доступен в браузере.','APK KuizStore ще не опубліковано. Каталог доступний у браузері.','KuizStore APK has not been published. Browse the catalog on the web.')}</p>`}</div></div>`;
    },
  };

  // ------------------------------------------------------------------ signed-in pages

  let polls = [];
  function poll(work, every) { work(); polls.push(setInterval(work, every)); }
  function stopPolling() { polls.forEach(clearInterval); polls = []; }

  /** Pages that need somebody signed in send everybody else to sign in. */
  function needMe() {
    if (me) return true;
    go("/account");
    return false;
  }

  const field = (id, label, value, opts) => {
    opts = opts || {};
    const tag = opts.lines
      ? `<textarea class="field" id="${id}" rows="${opts.lines}" maxlength="${opts.max || 6000}">${esc(value || "")}</textarea>`
      : `<input class="field" id="${id}" value="${esc(value || "")}" maxlength="${opts.max || 300}" ${opts.placeholder ? `placeholder="${esc(opts.placeholder)}"` : ""}>`;
    return `<label class="label">${esc(label)}${tag}${opts.note ? `<span class="note">${opts.note}</span>` : ""}</label>`;
  };
  const value = (id) => (view.querySelector("#" + id) || {}).value || "";

  /** Signing in: Telegram's bot or Google in a window of its own, while this page asks whether it is done. */

  Object.assign(pages, {
    async settings() {
      document.title = t("Настройки", "Налаштування", "Settings") + " · KuizStore";
      const lang = kept.get("ks_lang"), look = kept.get("ks_theme"), unverified = kept.get("ks_unverified") === "1";
      const choice = (key, current, options) => `<div class="choices">${options.map(([v, l]) =>
        `<button class="chip ${v === current ? "on" : ""}" data-set="${key}" data-value="${v}">${l}</button>`).join("")}</div>`;
      view.innerHTML = `<div style="max-width:640px;margin:0 auto"><h1 class="page-title">${t("Настройки", "Налаштування", "Settings")}</h1>
        <div class="section"><h2>${t("Вид", "Вигляд", "Look")}</h2><div class="rows">
          <div class="setting"><b>${t("Язык", "Мова", "Language")}</b>${choice("ks_lang", lang, [["", t("Как в системе", "Як у системі", "System")],
            ["ru", "Русский"], ["uk", "Українська"], ["en", "English"], ["kk", "Қазақша"]])}</div>
          <div class="setting"><b>${t("Тема", "Тема", "Theme")}</b>${choice("ks_theme", look, [["", t("Как в системе", "Як у системі", "System")],
            ["light", t("Светлая", "Світла", "Light")], ["dark", t("Тёмная", "Темна", "Dark")]])}</div>
        </div></div>
        <div class="section"><h2>${t("О магазине", "Про магазин", "About")}</h2><div class="rows">
          <a href="${link("/get")}" data-link><div class="grow"><b>${t("Скачать KuizStore", "Завантажити KuizStore", "Get KuizStore")}</b></div>›</a>
          <a href="/privacy/"><div class="grow"><b>${t("Конфиденциальность", "Конфіденційність", "Privacy")}</b></div>›</a>
          <a href="/terms/"><div class="grow"><b>${t("Условия", "Умови", "Terms")}</b></div>›</a>
        </div></div></div>`;
      view.querySelectorAll("[data-set]").forEach((b) => (b.onclick = () => {
        kept.set(b.dataset.set, b.dataset.value);
        // the words of the whole page change with the language, so it is read again
        if (b.dataset.set === "ks_lang") return location.reload();
        if (b.dataset.value) document.documentElement.dataset.theme = b.dataset.value;
        else delete document.documentElement.dataset.theme;
        view.querySelectorAll(`[data-set="${b.dataset.set}"]`).forEach((x) => x.classList.toggle("on", x === b));
      }));
    },

    async account() {
      if(!me){view.innerHTML=`<div class="profile"><h1>${t('Вход в KuizStore','Вхід у KuizStore','Sign in to KuizStore')}</h1><p>Markol Auth</p><div class="actions"><a class="btn filled" href="/login/google">Google</a><a class="btn tonal" href="/login/telegram">Telegram</a></div></div>`;return;}
      view.innerHTML=`<div style="max-width:640px;margin:auto"><div class="profile">${avatar(me,112)}<h1>${esc(me.display)}</h1><a href="/u/${encodeURIComponent(me.nick)}" data-link>@${esc(me.nick)}</a></div>
      ${field('f-display',t('Имя',"Ім’я",'Name'),me.display,{max:40})}${field('f-nick',t('Ник','Нік','Nick'),me.nick,{max:20})}${field('f-bio',t('О себе','Про себе','About'),me.bio,{lines:3,max:300})}
      <label class="label">${t('Аватар','Аватар','Avatar')}<input type="file" accept="image/png,image/jpeg,image/webp" id="avatar-file"></label><button class="btn filled" id="save">${t('Сохранить','Зберегти','Save')}</button>
      ${me.admin?'<a class="btn tonal" href="/admin">Админка</a>':''}<button class="btn outlined" id="out">${t('Выйти','Вийти','Sign out')}</button></div>`;
      view.querySelector('#save').onclick=act(async()=>{me=await api('/me','PATCH',{display:value('f-display'),nick:value('f-nick'),bio:value('f-bio')});paintBar();render();});
      view.querySelector('#avatar-file').onchange=act(async e=>{if(e.target.files[0]){await upload('/me/avatar',e.target.files[0]);me=await api('/me');render();}});
      view.querySelector('#out').onclick=act(async()=>{await api('/auth/logout','POST',{});me=null;csrf='';paintBar();go('/');});
    },

    async dev(){ return pages.admin(); },

    async submit() {
      if (!needMe() || !me.admin) throw new Error("Owner only");
      document.title = t("Заявка", "Заявка", "Request") + " · KuizStore";
      view.innerHTML = `<div style="max-width:640px"><h1 class="page-title">${t("Добавление приложения", "Додавання застосунку", "Add application")}</h1>
        ${field("s-name", t("Название", "Назва", "Name"), "", { max: 40 })}
        ${field("s-pkg", t("Имя пакета", "Ім'я пакета", "Package name"), "", { max: 120, placeholder: "com.example.app" })}
        ${field("s-git", t("Исходный код", "Вихідний код", "Source code"), "", { placeholder: "https://…",
          note: t("ссылка на GitHub, Forgejo или другой открытый git", "посилання на GitHub, Forgejo чи інший відкритий git", "a link to GitHub, Forgejo or another public git") })}
        ${field("s-license", t("Лицензия", "Ліцензія", "Licence"), "", { max: 60, placeholder: "GPL-3.0, MIT, Apache-2.0…" })}
        ${field("s-summary", t("Кратко", "Коротко", "Summary"), "", { max: 140 })}
        ${field("s-description", t("Описание", "Опис", "Description"), "", { lines: 6, note: t("можно маркдаун", "можна маркдаун", "Markdown works") })}
        <label class="check"><input type="checkbox" id="s-open"> ${t("Весь исходный код открыт, и апк собирается из него", "Весь вихідний код відкритий, і апк збирається з нього", "All of the source is open, and the apk is built from it")}</label>
        <button class="btn filled big" id="send">${t("Отправить", "Надіслати", "Send")}</button></div>`;
      view.querySelector("#send").onclick = act(async () => {
        if (!view.querySelector("#s-open").checked) { toast(t("Магазин только для открытого кода", "Магазин лише для відкритого коду", "The store is for open source only")); return; }
        const said = await api("/apps", "POST", { name: value("s-name"), package: value("s-pkg").trim(), git: value("s-git").trim(),
          license: value("s-license"), summary: value("s-summary"), description: value("s-description") });
        history.replaceState(null, "", link("/dev"));
        go("/edit/" + said.id);
      });
    },

    async edit(id) {
      if (!needMe() || !me.admin) throw new Error("Owner only");
      view.innerHTML = `<div class="loading"></div>`;
      const a = await api("/apps/" + id);
      if (!a.can_edit) throw new Error(t("Это не ваше приложение", "Це не ваш застосунок", "This is not your app"));
      document.title = a.name + " · KuizStore";
      const texts = { summary: Object.assign({ "": a.summary }, a.summary_tr), description: Object.assign({ "": a.description }, a.description_tr) };
      const notes = {};
      let lang = "";
      const buttons = (a.buttons || []).slice();
      const langs = [["", t("Основной", "Основний", "Main")], ["ru", "RU"], ["uk", "UK"], ["en", "EN"], ["kk", "KK"]];
      const langChips = (id) => `<div class="chips" data-langs="${id}">${langs.map(([k, l]) => `<button class="chip ${k === lang ? "on" : ""}" data-l="${k}">${l}</button>`).join("")}</div>`;
      const status = a.status !== "approved"
        ? `<div class="warn">${statusText(a.status)}${a.note ? ": " + esc(a.note) : ""}</div>`
        : `<a class="btn tonal" href="${link("/app/" + a.id)}" data-link>${t("Открыть страницу", "Відкрити сторінку", "Open the page")}</a>`;
      view.innerHTML = `<div style="max-width:720px"><h1 class="page-title">${esc(a.name)}</h1>${status}
        <div class="pictures"><label class="pic-icon">${appIcon(a.icon, 96)}<input type="file" accept="image/png,image/jpeg,image/webp" hidden data-pic="icon"></label>
          <label class="pic-cover">${a.cover ? `<img src="${esc(a.cover)}" alt="">` : t("Обложка 16:9", "Обкладинка 16:9", "Cover 16:9")}<input type="file" accept="image/png,image/jpeg,image/webp" hidden data-pic="cover"></label></div>
        <p class="note">${t("Нажмите на иконку или обложку, чтобы заменить. До 3 МБ.", "Натисніть на іконку чи обкладинку, щоб замінити. До 3 МБ.", "Click the icon or the cover to replace it. Up to 3 MB.")}</p>
        ${field("e-name", t("Название", "Назва", "Name"), a.name, { max: 40 })}
        ${langChips("texts")}
        <label class="label">${t("Кратко", "Коротко", "Summary")}<input class="field" id="e-summary" maxlength="140"></label>
        <label class="label">${t("Описание", "Опис", "Description")}<textarea class="field" id="e-description" rows="7" maxlength="6000"></textarea>
          <span class="note">${t("можно маркдаун: **жирный**, *курсив*, [ссылка](https://…), списки, # заголовки", "можна маркдаун: **жирний**, *курсив*, [посилання](https://…), списки, # заголовки",
            "Markdown works: **bold**, *italic*, [link](https://…), lists, # headings")}</span></label>
        ${field("e-git", t("Исходный код", "Вихідний код", "Source code"), a.git)}
        ${field("e-license", t("Лицензия", "Ліцензія", "Licence"), a.license, { max: 60 })}
        <div class="section"><h2>${t("Кнопки на странице", "Кнопки на сторінці", "Buttons on the page")}</h2><div id="buttons"></div>
          <button class="btn text" id="add-button">${svg(ICON.add)}${t("Добавить кнопку", "Додати кнопку", "Add a button")}</button></div>
        <button class="btn filled" id="save">${t("Сохранить", "Зберегти", "Save")}</button>
        ${me.admin ? `<div class="actions"><button class="btn tonal" data-judge="${a.official ? "unofficial" : "official"}">${a.official ? t("Убрать из KuizStore", "Прибрати з KuizStore", "Not KuizStore") : t("В KuizStore", "До KuizStore", "Make KuizStore")}</button>
          <button class="btn tonal" data-judge="${a.status === "approved" ? "hide" : "approve"}">${a.status === "approved" ? t("Скрыть", "Приховати", "Hide") : t("Одобрить", "Схвалити", "Approve")}</button></div>` : ""}

        <div class="section"><h2>${t("Новый выпуск", "Новий випуск", "New release")}</h2>
        ${a.status === "rejected" ? `<p class="note">${t("Приложение отклонено. Измени статус перед загрузкой.", "Заявку відхилено, завантажувати випуски не можна.", "The request was rejected, releases can't be uploaded.")}</p>` : `
          ${field("r-version", t("Версия", "Версія", "Version"), "", { max: 40, note: t("как versionName в апк", "як versionName в апк", "as the apk's versionName") })}
          ${langChips("notes")}
          <label class="label">${t("Что нового", "Що нового", "What's new")}<textarea class="field" id="r-notes" rows="4" maxlength="3000"></textarea></label>
          <label class="check"><input type="checkbox" id="r-beta"> ${t("Бета (только поддержавшим)", "Бета (лише тим, хто підтримав)", "Beta (supporters only)")}</label>
          <label class="btn tonal">${svg(ICON.download)}<span id="apk-name">${t("Выбрать апк", "Вибрати апк", "Pick the apk")}</span><input type="file" accept=".apk,application/vnd.android.package-archive" hidden id="r-apk"></label>
          <progress id="r-progress" max="1" value="0" hidden></progress>
          <button class="btn filled" id="r-send">${t("Загрузить", "Завантажити", "Upload")}</button>`}</div>
        ${(a.releases || []).length ? `<div class="section"><h2>${t("Выпуски", "Випуски", "Releases")}</h2><div class="rows">${a.releases.map((r) =>
          `<div><div class="grow"><b>${esc(r.version)}</b>${r.beta ? " · beta" : ""}<div class="note">${statusText(r.status)}${r.note ? ": " + esc(r.note) : ""}</div></div></div>`).join("")}</div></div>` : ""}
      </div>`;

      view.insertAdjacentHTML('beforeend',`<div class="section"><h2>${t('Скриншоты','Знімки екрана','Screenshots')}</h2><input type="file" id="screenshot-file" accept="image/png,image/jpeg,image/webp"><div class="screenshots">${(a.screenshots||[]).map(i=>`<div><img src="${esc(i.url)}" alt=""><button class="btn text" data-shot-delete="${i.id}">${t('Удалить','Видалити','Delete')}</button></div>`).join('')}</div><button class="btn outlined" id="delete-app">${t('Удалить приложение','Видалити застосунок','Delete application')}</button></div>`);
      view.querySelector('#screenshot-file').onchange=act(async e=>{if(e.target.files[0]){await upload(`/apps/${id}/screenshots`,e.target.files[0]);render();}});
      view.querySelectorAll('[data-shot-delete]').forEach(b=>b.onclick=act(async()=>{await api('/screenshots/'+b.dataset.shotDelete,'DELETE',{});render();}));
      view.querySelector('#delete-app').onclick=act(async()=>{if(await ask(t('Удалить приложение?','Видалити застосунок?','Delete application?'))){await api('/apps/'+id,'DELETE',{});go('/admin');}});
      const sum = view.querySelector("#e-summary"), desc = view.querySelector("#e-description"), notesBox = view.querySelector("#r-notes");
      const showTexts = () => { sum.value = texts.summary[lang] || ""; desc.value = texts.description[lang] || ""; if (notesBox) notesBox.value = notes[lang] || ""; };
      sum.oninput = () => (texts.summary[lang] = sum.value);
      desc.oninput = () => (texts.description[lang] = desc.value);
      if (notesBox) notesBox.oninput = () => (notes[lang] = notesBox.value);
      view.querySelectorAll("[data-langs] [data-l]").forEach((b) => (b.onclick = () => {
        lang = b.dataset.l;
        view.querySelectorAll("[data-langs] [data-l]").forEach((x) => x.classList.toggle("on", x.dataset.l === lang));
        showTexts();
      }));
      showTexts();
      const tr = (m) => Object.fromEntries(Object.entries(m).filter(([k, v]) => k && v && v.trim()));

      const paintButtons = () => {
        view.querySelector("#buttons").innerHTML = buttons.length ? `<div class="rows">${buttons.map((b, i) => `<div><div class="grow"><b>${esc(b.title)}</b>
          <div class="note">${esc(b.url || t("окно с текстом", "вікно з текстом", "a window of text"))}</div></div><button class="btn text" data-drop="${i}">✕</button></div>`).join("")}</div>` : "";
        view.querySelectorAll("[data-drop]").forEach((x) => (x.onclick = () => { buttons.splice(+x.dataset.drop, 1); paintButtons(); }));
      };
      paintButtons();
      view.querySelector("#add-button").onclick = () => {
        const d = dialog(t("Новая кнопка", "Нова кнопка", "New button"), `
          <label class="label">${t("Надпись", "Напис", "Label")}<input class="field" id="b-title" maxlength="30"></label>
          <div class="chips"><button class="chip on" data-kind="link">${t("Ссылка", "Посилання", "Link")}</button><button class="chip" data-kind="text">${t("Окно с текстом", "Вікно з текстом", "Text window")}</button></div>
          <input class="field" id="b-url" value="https://" maxlength="300">
          <textarea class="field" id="b-text" rows="5" maxlength="4000" hidden placeholder="${t("Текст (можно маркдаун)", "Текст (можна маркдаун)", "Text (Markdown works)")}"></textarea>`,
          false, [t("Отмена", "Скасувати", "Cancel"), "OK"]);
        let kind = "link";
        d.querySelectorAll("[data-kind]").forEach((b) => (b.onclick = () => {
          kind = b.dataset.kind;
          d.querySelectorAll("[data-kind]").forEach((x) => x.classList.toggle("on", x === b));
          d.querySelector("#b-url").hidden = kind !== "link";
          d.querySelector("#b-text").hidden = kind === "link";
        }));
        d.querySelector("[data-ok]").onclick = () => {
          const title = d.querySelector("#b-title").value.trim();
          const url = d.querySelector("#b-url").value.trim(), words = d.querySelector("#b-text").value;
          if (!title || (kind === "link" ? url.length < 9 : !words.trim())) { toast(t("Заполните кнопку", "Заповніть кнопку", "Fill the button in")); return; }
          buttons.push(kind === "link" ? { title, url } : { title, text: words });
          d.close();
          paintButtons();
        };
      };
      view.querySelector("#save").onclick = act(async () => {
        await api("/apps/" + id, "PATCH", { name: value("e-name"), summary: texts.summary[""] || "", description: texts.description[""] || "",
          summary_tr: tr(texts.summary), description_tr: tr(texts.description), buttons, git: value("e-git").trim(), license: value("e-license") });
        toast(t("Сохранено", "Збережено", "Saved"));
      });
      view.querySelectorAll("[data-pic]").forEach((input) => (input.onchange = act(async () => {
        if (!input.files[0]) return;
        await upload(`/apps/${id}/${input.dataset.pic}`, input.files[0]);
        render();
      })));
      view.querySelectorAll("[data-judge]").forEach((b) => (b.onclick = act(async () => {
        await api("/admin/apps/" + id, "POST", { action: b.dataset.judge });
        render();
      })));
      const apk = view.querySelector("#r-apk");
      if (apk) {
        apk.onchange = () => (view.querySelector("#apk-name").textContent = apk.files[0] ? apk.files[0].name : "");
        view.querySelector("#r-send").onclick = act(async () => {
          const file = apk.files[0];
          if (!value("r-version").trim() || !file) { toast(t("Нужны версия и апк", "Потрібні версія та апк", "A version and an apk are needed")); return; }
          const bar = view.querySelector("#r-progress");
          bar.hidden = false;
          const made = await api(`/apps/${id}/releases`, "POST", { version: value("r-version").trim(), notes: notes[""] || "", notes_tr: tr(notes),
            beta: view.querySelector("#r-beta").checked });
          const said = await upload(`/releases/${made.id}/file`, new File([file], file.name, { type: "application/vnd.android.package-archive" }), (p) => (bar.value = p));
          toast(said.status === "approved" ? t("Выпуск опубликован", "Випуск опубліковано", "Released") : t("Выпуск отправлен на проверку", "Випуск надіслано на перевірку", "Sent for review"));
          render();
        });
      }
    },

    async admin() {
      if(!needMe()||!me.admin)throw new Error('Owner only');
      const [apps,users,stats]=await Promise.all([api('/admin/apps'),api('/admin/users'),api('/admin/stats')]);
      view.innerHTML=`<h1>KuizStore · ${t('Управление','Керування','Administration')}</h1><div class="actions"><a class="btn filled" href="/submit" data-link>${t('Добавить приложение','Додати застосунок','Add application')}</a></div><div class="rows">${apps.apps.map(a=>`<a href="/edit/${a.id}" data-link>${appIcon(a.icon,48)}<div class="grow"><b>${esc(a.name)}</b><div class="note">${esc(a.package)} · ${statusText(a.status)}</div></div></a>`).join('')}</div><h2>${t('Пользователи','Користувачі','Users')}</h2><div class="rows">${users.users.map(p=>`<div>${avatar(p,40)}<a class="grow" href="/u/${encodeURIComponent(p.nick)}" data-link>${name(p)}</a>${p.admin?'':`<button class="btn outlined" data-ban="${esc(p.nick)}" data-action="${p.banned?'unban':'ban'}">${p.banned?'Unblock':'Block'}</button>`}</div>`).join('')}</div><h2>${t('Загрузки','Завантаження','Downloads')}</h2><div class="rows">${stats.downloads.map(d=>`<div>Release #${d.release_id}: ${d.count}</div>`).join('')}</div><h2>${t('Аудит','Аудит','Audit')}</h2><div class="rows">${stats.audit.map(e=>`<div>${esc(when(e.created))} · #${e.user_id} · ${esc(e.action)}</div>`).join('')}</div>`;
      view.querySelectorAll('[data-ban]').forEach(b=>b.onclick=act(async()=>{await api('/admin/ban','POST',{nick:b.dataset.ban,action:b.dataset.action});render();}));
    },
  });

  function judgeWith(path, action, after) {
    return act(async () => {
      let note = "";
      if (action === "reject") {
        note = await new Promise((answer) => {
          const d = dialog(t("Причина", "Причина", "Why"), `<textarea class="field" rows="3" maxlength="500"
            placeholder="${t("Автор увидит её у себя", "Автор побачить її у себе", "The author will see it")}"></textarea>`, false,
            [t("Отмена", "Скасувати", "Cancel"), t("Отклонить", "Відхилити", "Reject")]);
          let said = null;
          d.querySelector("[data-ok]").onclick = () => { said = d.querySelector("textarea").value; d.close(); };
          d.addEventListener("close", () => answer(said));
        });
        if (note === null) return;
      }
      await api(path, "POST", { action, note });
      toast(t("Готово", "Готово", "Done"));
      after();
    });
  }

  /** A message of a few emoji and nothing else is shown big, without a bubble, as Telegram does. */
  function statusText(status) {
    return { approved: t("опубликовано", "опубліковано", "published"), pending: t("на проверке", "на перевірці", "in review"),
      rejected: t("отклонено", "відхилено", "rejected"), draft: t("черновик", "чернетка", "draft"), hidden: t("скрыто", "приховано", "hidden") }[status] || status;
  }

  // ------------------------------------------------------------------ the bar

  function paintBar(){const who=document.querySelector('[data-account]');who.innerHTML=me?avatar(me,34):svg(ICON.person);}

  function appCard(a) {
    const summary = pick(a.summary_tr, a.summary);
    return `<a class="app-card" href="${link("/app/" + a.id)}" data-link>${appIcon(a.icon, 64)}<div class="body">
      <div class="name"><span>${esc(a.name)}</span>${a.official ? svg(ICON.verified, "verified") : ""}</div>
      <div class="who">${esc((a.author && a.author.display) || "KuizStore")}</div>
      ${summary ? `<div class="sum">${esc(summary)}</div>` : ""}
      <div class="meta">${a.ratings ? stars(a.rating) : ""}${a.version ? `<span class="pill">${esc(a.version)}</span>` : ""}
        ${a.status === "pending" ? `<span class="pill" style="background:var(--error-container);color:var(--on-error-container)">${t("не проверено", "не перевірено", "unreviewed")}</span>` : ""}</div>
    </div></a>`;
  }

  function review(c) {
    const who = c.author || {};
    const voted = (n) => (c.my_vote === n ? " on" : "");
    return `<div class="review" data-review="${c.id}"><a href="${link("/u/" + encodeURIComponent(who.nick))}" data-link>${avatar(who, 40)}</a><div class="grow">
      ${c.pinned ? `<div class="pinned">📌 ${t("Закреплено", "Закріплено", "Pinned")}</div>` : ""}
      <a href="${link("/u/" + encodeURIComponent(who.nick))}" data-link style="color:inherit;text-decoration:none">${name(who, 20)}</a>
      <div class="note">${c.stars ? '<span class="star">' + "★".repeat(c.stars) + "</span> " : ""}${when(c.created)}${c.edited ? " · " + t("изменён", "змінено", "edited") : ""}</div>
      ${c.text ? `<div class="text">${esc(c.text)}</div>` : ""}
      ${c.maker_vote ? `<div class="maker-vote ${c.maker_vote > 0 ? "up" : "down"}">${c.maker_vote > 0 ? "👍 " + t("Понравилось автору", "Сподобалося автору", "The author liked this")
        : "👎 " + t("Не понравилось автору", "Не сподобалося автору", "The author disliked this")}</div>` : ""}
      <div class="votes">${c.can_reply ? `<button class="vote" data-answer-review>${c.reply ? t("изменить ответ", "змінити відповідь", "edit reply") : t("ответить", "відповісти", "reply")}</button>` : ""}<button class="vote${voted(1)}" data-vote="${c.my_vote === 1 ? 0 : 1}">👍 ${c.likes || 0}</button>
        <button class="vote${voted(-1)}" data-vote="${c.my_vote === -1 ? 0 : -1}">👎 ${c.dislikes || 0}</button>
        ${c.can_pin ? `<button class="vote" data-pin="${c.pinned ? 0 : 1}">📌 ${c.pinned ? t("открепить", "відкріпити", "unpin") : t("закрепить", "закріпити", "pin")}</button>` : ""}
        ${c.can_delete ? `<button class="vote" data-delete>${t("удалить", "видалити", "delete")}</button>` : ""}</div>
      ${c.reply ? `<div class="reply"><div class="who">${avatar(c.reply.author, 22)}${name(c.reply.author, 16)}</div>
        <div class="note">${t("Ответ разработчика · ", "Відповідь розробника · ", "Developer's reply · ")}${when(c.reply.created)}</div>
        <div class="text">${esc(c.reply.text)}</div></div>` : ""}
    </div></div>`;
  }

  /** Writing or changing one's review: the stars and the words, posted together. */
  function writeReview(a, chosen, done) {
    const mine = a.my_review || {};
    const d = dialog(a.name, `
      <div class="pick-stars big">${[1, 2, 3, 4, 5].map((n) => `<button data-n="${n}">★</button>`).join("")}</div>
      <textarea class="field" rows="5" maxlength="1000" placeholder="${t("Расскажите, что понравилось и что нет", "Розкажіть, що сподобалося і що ні",
        "Tell what you liked and what you didn't")}">${esc(mine.text || "")}</textarea>
      <div class="note">${t("Отзыв виден всем, вместе с вашим ником", "Відгук бачать усі, разом із вашим ніком", "Everyone sees the review, with your nick")}</div>`,
      false, [t("Отмена", "Скасувати", "Cancel"), t("Опубликовать", "Опублікувати", "Post")]);
    const paint = () => d.querySelectorAll("[data-n]").forEach((b) => b.classList.toggle("on", +b.dataset.n <= chosen));
    d.querySelectorAll("[data-n]").forEach((b) => (b.onclick = () => { chosen = +b.dataset.n; paint(); }));
    paint();
    d.querySelector("[data-ok]").onclick = act(async () => {
      if (!chosen) { toast(t("Поставьте оценку", "Поставте оцінку", "Pick the stars")); return; }
      await api(`/apps/${a.id}/comments`, "POST", { stars: chosen, text: d.querySelector("textarea").value.trim() });
      d.close();
      done();
    });
  }

  /** A window over the page; [buttons] are a dismissing one and a confirming one (data-ok). */
  function dialog(title, body, full, buttons) {
    const d = document.createElement("dialog");
    if (full) d.className = "full";
    const end = buttons
      ? `<div class="end"><button class="btn text" data-close>${esc(buttons[0])}</button><button class="btn filled" data-ok>${esc(buttons[1])}</button></div>`
      : `<div class="end"><button class="btn text" data-close>OK</button></div>`;
    d.innerHTML = full
      ? `<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px"><button class="icon-btn" data-close>${svg(ICON.back)}</button><h3 style="margin:0">${esc(title)}</h3></div><div style="max-width:760px;margin:0 auto">${body}</div>`
      : `<h3>${esc(title)}</h3>${body}${end}`;
    document.body.appendChild(d);
    d.addEventListener("close", () => d.remove());
    d.addEventListener("click", (e) => { if (e.target === d || e.target.closest("[data-close]")) d.close(); });
    d.showModal();
    return d;
  }

  function confirmDialog(title, text, yes) {
    const d = dialog(title, text ? `<p>${esc(text)}</p>` : "", false, [t("Отмена", "Скасувати", "Cancel"), "OK"]);
    d.querySelector("[data-ok]").onclick = () => { d.close(); yes(); };
  }
  const ask = (title) => new Promise((answer) => {
    const d = dialog(title, "", false, [t("Отмена", "Скасувати", "Cancel"), "OK"]);
    let said = false;
    d.querySelector("[data-ok]").onclick = () => { said = true; d.close(); };
    d.addEventListener("close", () => answer(said));
  });

  // ------------------------------------------------------------------ the address

  let shownPage = "";
  async function render() {
    stopPolling();
    const page = location.pathname;
    if (page !== shownPage) {
      shownPage = page;
      view.classList.remove("enter");
      void view.offsetWidth;
      view.classList.add("enter");
    }
    const path = location.pathname.slice(BASE.length) || "/";
    const query = new URLSearchParams(location.search);
    window.scrollTo(0, 0);
    try {
      let m;
      if ((m = path.match(/^\/app\/(\d+)\/?$/))) await pages.app(m[1]);
      else if ((m = path.match(/^\/u\/([A-Za-z0-9_.]+)\/?$/))) await pages.user(m[1]);
      else if (path.startsWith("/search")) await pages.search(query.get("q") || "", query.get("k"));
      else if (path.startsWith("/get")) await pages.get();
      else if (path.startsWith("/account")) await pages.account();
      else if (path.startsWith("/dev")) await pages.dev();
      else if (path.startsWith("/submit")) await pages.submit();
      else if ((m = path.match(/^\/edit\/(\d+)\/?$/))) await pages.edit(m[1]);
      else if (path === "/admin") await pages.admin();
      else if (path.startsWith("/settings")) await pages.settings();
      else if (path === "/") await pages.home();
      else throw new Error(t("Страница не найдена","Сторінку не знайдено","Page not found"));
    } catch (e) {
      view.innerHTML = `<p class="empty">${esc(e.message)}</p><a class="btn tonal" href="${link("/")}" data-link>${t("На главную", "На головну", "Home")}</a>`;
    }
  }

  function go(path) {
    const [p, q] = path.split("?");
    history.pushState(null, "", link(p) + (q !== undefined ? "?" + q : ""));
    render();
  }

  document.addEventListener("click", (e) => {
    const a = e.target.closest("a[data-link]");
    if (!a || e.metaKey || e.ctrlKey || e.shiftKey || e.button) return;
    e.preventDefault();
    go(a.getAttribute("href").slice(BASE.length) || "/");
  });
  window.addEventListener("popstate", render);
  document.addEventListener("pointerdown", (e) => {
    const surface = e.target.closest(".btn, .icon-btn, .chip, .app-card, .segmented button, .tabs button, .rows > a, .rows > label, .person");
    if (!surface || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const box = surface.getBoundingClientRect();
    const wave = document.createElement("span");
    const side = Math.max(box.width, box.height) * 2.2;
    wave.className = "ripple";
    wave.style.cssText = `width:${side}px;height:${side}px;left:${e.clientX - box.left - side / 2}px;top:${e.clientY - box.top - side / 2}px`;
    surface.appendChild(wave);
    setTimeout(() => wave.remove(), 600);
  });
  window.addEventListener("scroll", () => bar.classList.toggle("lifted", scrollY > 4), { passive: true });

  // the bar and the footer, said in the person's language
  document.querySelector("[data-search]").setAttribute("href", link("/search"));
  document.querySelector("[data-settings]").setAttribute("href", link("/settings"));
  document.querySelector(".brand").setAttribute("href", link("/"));
  document.querySelector("[data-get]").setAttribute("href", link("/get"));
  document.querySelector("[data-get]").textContent = t("Скачать", "Завантажити", "Get");
  document.querySelector("[data-privacy]").textContent = t("Конфиденциальность", "Конфіденційність", "Privacy");
  document.querySelector("[data-terms]").textContent = t("Условия", "Умови", "Terms");
  document.documentElement.lang = LANG;
  paintBar();
  // who is signed in is known before the first page, so it is drawn for them
  api('/session').then(s=>{me=s.me;csrf=s.csrf;}).catch(()=>{}).then(()=>{paintBar();render();});
})();