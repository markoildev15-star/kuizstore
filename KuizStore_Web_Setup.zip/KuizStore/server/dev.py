"""Loopback-only, guest catalog preview. Never use this HTTP helper in production."""
import mimetypes,os,urllib.parse
from pathlib import Path
import store
SITE=Path(__file__).resolve().parents[1]/'site'
class Preview(store.Handler):
 def route(self,method):
    path=urllib.parse.urlsplit(self.path).path
    if path.startswith('/api/'):
        if method!='GET':store.refuse(403,'Read-only local preview')
        return super().route(method)
    if method!='GET':store.refuse(403,'Read-only local preview')
    if path.startswith(('/login/','/auth/','/admin')):store.refuse(403,'Authentication requires the configured HTTPS host')
    file=(SITE/urllib.parse.unquote(path).lstrip('/')).resolve()
    if not file.is_relative_to(SITE):store.refuse(404,'Not found')
    if file.is_dir():file=file/'index.html'
    if not file.is_file():file=SITE/'web/index.html'
    return 200,{'__static__':file}
 def answer(self,code,body):
    if isinstance(body,dict) and '__static__' in body:
        file=body['__static__'];data=file.read_bytes()
        self.send_response(code);self.send_header('Content-Type',mimetypes.guess_type(file)[0] or 'application/octet-stream');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    else:super().answer(code,body)
if __name__=='__main__':
 store.initialize()
 print('Guest preview: http://127.0.0.1:8093',flush=True)
 store.ThreadingHTTPServer(('127.0.0.1',8093),Preview).serve_forever()
