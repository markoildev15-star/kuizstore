"""Inspect without executing APKs. Requires Android build-tools apksigner and aapt."""
import os, re, shutil, subprocess, zipfile

def inspect_apk(path):
    from store import refuse
    for tool in ('apksigner','aapt'):
        if not shutil.which(tool):
            refuse(503,'Install Android build-tools: '+tool)
    try:
        with zipfile.ZipFile(path) as z:
            names=z.namelist()
            if len(names)>100000 or 'AndroidManifest.xml' not in names or len(names)!=len(set(names)):
                refuse(415,'Invalid APK archive')
            if sum(i.file_size for i in z.infolist())>2*1024**3:
                refuse(413,'Expanded APK too large')
        sign=subprocess.run(['apksigner','verify','--print-certs',path],capture_output=True,text=True,timeout=60)
        if sign.returncode: refuse(415,'APK signature verification failed')
        fingerprints=re.findall(r'Signer #\d+ certificate SHA-256 digest: ([0-9a-fA-F]+)',sign.stdout)
        if not fingerprints: refuse(415,'No verified signer')
        result=subprocess.run(['aapt','dump','badging',path],capture_output=True,text=True,timeout=30)
        if result.returncode: refuse(415,'Invalid Android manifest')
        p=re.search(r"package: name='([^']+)' versionCode='(\d+)' versionName='([^']*)'",result.stdout)
        sdk=re.search(r"sdkVersion:'(\d+)'",result.stdout)
        if not p or not sdk: refuse(415,'Missing APK metadata')
        return dict(package=p[1],version_code=int(p[2]),version=p[3],min_sdk=int(sdk[1]),signer=','.join(sorted(x.lower() for x in fingerprints)))
    except (zipfile.BadZipFile,subprocess.TimeoutExpired,OSError):
        refuse(415,'APK could not be verified')
