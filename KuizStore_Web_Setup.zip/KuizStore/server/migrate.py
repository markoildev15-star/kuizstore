"""Offline, explicit migration. Always snapshots the source with SQLite backup."""
import argparse,datetime,json,os,sqlite3,tempfile
from pathlib import Path

def migrate(source):
    source=Path(source).resolve()
    if not source.is_file(): raise ValueError('Source database does not exist')
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    backup=source.with_name(source.name+'.backup-'+stamp)
    old=sqlite3.connect(source)
    old.row_factory=sqlite3.Row
    tables={r[0] for r in old.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if 'identity' in {r[1] for r in old.execute('PRAGMA table_info(users)')}:
        old.close();raise ValueError('Already migrated')
    with sqlite3.connect(backup) as b: old.backup(b)
    os.chmod(backup,0o600)
    target=source.with_name(source.name+'.kuiz-'+stamp)
    new=sqlite3.connect(target)
    new.executescript(Path(__file__).with_name('schema.sql').read_text())
    counts={}
    try:
        for table in ('users','apps','releases','comments','ratings','comment_votes'):
            if table not in tables: continue
            columns={r[1] for r in new.execute('PRAGMA table_info('+table+')')}
            count=0
            for row in old.execute('SELECT * FROM '+table):
                d={k:row[k] for k in row.keys() if k in columns}
                if table=='releases' and d.get('kind')!='apk': continue
                if table in ('apps','releases'): d['status']='hidden' # explicit owner review before redistribution
                if table=='releases': d['url']=''
                if table in ('users','apps'):
                    for field in ('avatar','icon','cover'):
                        if field in d and not str(d[field]).startswith('img/'): d[field]=''
                names=list(d)
                new.execute('INSERT INTO '+table+'('+','.join(names)+') VALUES('+','.join('?' for _ in names)+')',[d[k] for k in names]);count+=1
            counts[table]=count
        new.commit()
        assert new.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    except Exception:
        new.close();old.close();target.unlink(missing_ok=True);raise
    new.close();old.close()
    os.chmod(target,0o600)
    # Keep source untouched. Operator swaps files only while the service is stopped.
    return {'backup':str(backup),'migrated':str(target),'copied':counts,'source_unchanged':True}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('database');args=p.parse_args()
    print(json.dumps(migrate(args.database),ensure_ascii=False,indent=2))
