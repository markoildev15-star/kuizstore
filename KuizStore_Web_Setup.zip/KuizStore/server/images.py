"""Decode then re-encode uploads; metadata and trailing arbitrary data are removed."""
import hashlib,os,warnings

def sanitize(path):
    from store import refuse
    try:
        from PIL import Image,UnidentifiedImageError
    except ImportError:
        refuse(503,'Install Pillow to validate images')
    Image.MAX_IMAGE_PIXELS=20_000_000
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error',Image.DecompressionBombWarning)
            with Image.open(path) as im:
                if im.format not in ('PNG','JPEG','WEBP'): refuse(415,'Unsupported image')
                im.load()
                fmt=im.format
                clean=im.convert('RGB' if fmt=='JPEG' else 'RGBA')
                clean.save(path+'.clean',format=fmt)
        if os.path.getsize(path+'.clean')>3<<20: refuse(413,'Decoded image is too large')
        os.replace(path+'.clean',path)
    except (OSError,ValueError,Image.DecompressionBombWarning,Image.DecompressionBombError):
        refuse(415,'Invalid image')
    finally:
        if os.path.exists(path+'.clean'): os.remove(path+'.clean')
