# Attribution

KuizStore web fork derives from MargyStore by narezany / the MargyStore contributors.
Original project: https://git.narez.xyz/narezany/MargyStore.git
Original license: GPL-3.0-or-later. The original GPL text is retained in LICENSE.

The original Python/SQLite catalog, profile and review functions, web layout,
styles, animations, localization and editor are adapted here. New authentication,
owner-only authorization, validation, migration and deployment integration were
added for KuizStore. This is an independently modified fork, not an upstream release.

The Markol Auth integration was informed by the supplied Flask test-client example.
It is not a copy of or replacement for the Markol Auth server.

No upstream APKs, signing keys, owner identifiers or seeded catalog are distributed.
Application uploads remain subject to their respective authors' licenses.
